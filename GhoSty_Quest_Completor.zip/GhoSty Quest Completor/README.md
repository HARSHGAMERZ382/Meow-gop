<div align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.herokuapp.com?font=JetBrains+Mono&size=38&pause=1000&color=00F5FF&center=true&vCenter=true&random=false&width=600&lines=GhoSty+Quest+Completor;Automated+Discord+Quest+Suite;Multi-Account+%2B+Captcha+Relay" alt="Typing SVG" /></a>
  <br/>
  <a href="https://discord.gg/asMJGgDA7u"><img src="https://invidget.switchblade.xyz/asMJGgDA7u" alt="Discord Invite"/></a>
  <br/>
  <small><p>Join our community server for updates, releases, and direct support!<br>
  Need direct assistance? Shoot a friend request to <code>@jijaghosty</code> on Discord.</p></small>
</div>

---

The most advanced, lightweight, and secure Discord Quest automation suite. Designed for effortless multi-account quest completion, real-time progress tracking, and instant promo code reward claiming across Windows, Linux, macOS, and Android (Termux).

> [!IMPORTANT]
> ⚠️🚨 **DISCLAIMER:** This software is provided strictly for educational and security research purposes. Automated interaction with Discord APIs and user tokens is against Discord's Terms of Service. The developers assume zero liability for account penalties, bans, or misuse. Always operate responsibly.

---

<div align="center">
  <img src="https://capsule-render.vercel.app/api?type=transparent&color=gradient&customColorList=00f5ff,0070f3&height=60&section=header&text=✨%20Core%20Features&fontSize=38&fontAlignY=35" alt="Features" />
</div>

- ⚡ **Automated Quest Engine**: Detects, accepts, and solves active Discord Quests autonomously in the background.
- 🚀 **Universal Direct Web Solver**: Zero-latency native in-browser puzzle verification running directly in any modern browser (Chrome, Edge, Firefox, Brave, Safari, Mobile Chrome) with instant token submission, eliminating headless browser lag and heavy resource consumption.
- 🛡️ **Chrome TLS Impersonation & Telemetry Parity**: Built on `curl_cffi` with matching `Chrome/120` TLS fingerprints and standardized Desktop Client `X-Super-Properties` across all platforms (Windows, Linux, macOS, and Android Termux), ensuring all quests (including all `WATCH_VIDEO` video quests) appear and progress without 401 Unauthorized errors.
- ⏱️ **Authoritative Heartbeat Synchronization**: 61-second cadence pulses synchronized directly with Discord's server bucket counter (`user_status.progress`), preventing premature loop exits.
- 📱 **Termux & Mobile First**: Full Android Termux compatibility with multi-stage auto-opener intents (`termux-open-url`, `termux-open`, and Android native `am start` targeting Google Chrome) and embedded `Bitcount Prop Single Light` typography.
- 👥 **Multi-Account Token Matrix**: Hot-swap between Discord accounts on the fly with automatic token validation and multi-account batch auto-completion.
- 🎁 **Automated Reward Redemption**: Auto-claims reward codes and in-game Discord inventory items (Orbs, badges, game keys) upon quest completion.
- 🎨 **Monochrome Terminal Matrix UI**: High-contrast, clean 2D ASCII art terminal interface with live status tables, responsive width scaling, and color-coded logging.

---

<div align="center">
  <img src="https://capsule-render.vercel.app/api?type=transparent&color=gradient&customColorList=ff0055,ff5500&height=60&section=header&text=⚠️%20Quest%20Compatibility%20Notice&fontSize=34&fontAlignY=35" alt="Notice" />
</div>

### 🚨 Current Limitation: Embedded Activities / Achievement Quests

Discord distributes quests under multiple task categories:

| Quest Task Type | Status | Automation Method |
| :--- | :---: | :--- |
| **`PLAY` (Desktop Games)** | ✅ **Supported** | Automated via Heartbeat Presence (`POST /quests/{id}/heartbeat`) |
| **`VIDEO` (Watch Video / Stream)** | ✅ **Supported** | Automated via Video Progress Pulses |
| **`ACHIEVEMENT_IN_ACTIVITY`** | ❌ **Currently Not Doable** | *Requires interactive voice channel presence & embedded game RPC* |

> [!WARNING]
> **Achievement Quests (`ACHIEVEMENT_IN_ACTIVITY`) are currently unsupported.**  
> Quests such as *Audible's Exoplanet* require launching an interactive embedded web application inside an active Discord voice channel. Discord immediately rejects standard game presence heartbeats for these activities with `403 Forbidden` (`10008: Unknown Message`). These quests must be played manually within the official Discord desktop client.

---

<div align="center">
  <img src="https://capsule-render.vercel.app/api?type=transparent&color=gradient&customColorList=b500ff,ff007f&height=60&section=header&text=🛠️%20Setup%20&%20Installation&fontSize=38&fontAlignY=35" alt="Setup" />
</div>

### 1️⃣ Universal Setup Assistant

GhoSty Quest Completor includes an automated cross-platform setup wizard that prepares dependencies, builds native wheels, and scaffolds launcher scripts:

```bash
python setup.py
```

*The setup wizard will guide you through adding Discord tokens to `tokens.txt` and generate ready-to-run helpers in `setup_files/` (`run.bat`, `run.sh`, `termux_setup.sh`).*

---

### 2️⃣ Manual Installation

#### 🪟 Windows (CMD / PowerShell)
```cmd
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```
*(Or simply double-click `setup_files\run.bat`)*

#### 🐧 Linux & 🍎 macOS
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 main.py
```
*(Or run `bash setup_files/run.sh`)*

#### 📱 Android (Termux)
```bash
bash setup_files/termux_setup.sh
```
*`termux_setup.sh` automatically configures `x11-repo`, `tur-repo`, `termux-tools`, installs native build tools (`clang`, `make`, `libcurl`), and prepares the environment.*

---

<div align="center">
  <img src="https://capsule-render.vercel.app/api?type=transparent&color=gradient&customColorList=00ffaa,00e5ff&height=60&section=header&text=🎮%20Terminal%20Control%20Matrix&fontSize=36&fontAlignY=35" alt="Control Matrix" />
</div>

When launched, GhoSty Quest Completor presents an interactive terminal control suite:

```text
  ╭──────────────────────────────────────────────────────────────────────────╮
  │                            AVAILABLE ACTIONS                             │
  ├──────────────────────────────────────────────────────────────────────────┤
  │ <01> List Quests        │ <04> Filter (Play)      │ <07> Switch Account  │
  │ <02> Solve Single       │ <05> Filter (Video)     │ <08> Add Token       │
  │ <03> Auto-Solve All     │ <06> Claim Rewards      │ <09> Exit Suite      │
  ╰──────────────────────────────────────────────────────────────────────────╯
```

| Action | Function | Details |
| :--- | :--- | :--- |
| `<01> List Quests` | Live Quest Directory | Fetches and displays all available, in-progress, and completed quests for the active token. |
| `<02> Solve Single` | Targeted Quest Runner | Allows selecting a specific quest by ID or number to execute step-by-step. |
| `<03> Auto-Solve All` | Batch Autonomous Runner | Iterates through all eligible quests sequentially, solves them, and claims rewards automatically. |
| `<04> Filter (Play)` | Filter Game Quests | Isolates desktop game playtime quests (e.g., Where Winds Meet, Warframe). |
| `<05> Filter (Video)` | Filter Video Quests | Isolates media/stream quests. |
| `<06> Claim Rewards` | Redeem Completed Quests | Submits reward claim requests and extracts promotional redemption codes or Discord inventory items. |
| `<07> Switch Account` | Token Hot-Swapping | Switches active session to another token configured in `tokens.txt` without restarting. |
| `<08> Add Token` | Token Registration | Appends and validates a new Discord account token into `tokens.txt`. |
| `<09> Exit Suite` | Graceful Shutdown | Disconnects Discord Gateway presence, stops background relay, and terminates cleanly. |

---

<div align="center">
  <img src="https://capsule-render.vercel.app/api?type=transparent&color=gradient&customColorList=ffaa00,ff5500&height=60&section=header&text=⚙️%20Configuration%20Reference&fontSize=36&fontAlignY=35" alt="Config" />
</div>

### `config.json`
```json
{
  "captcha_relay": true,
  "relay_host": "0.0.0.0",
  "relay_port": 8787,
  "auto_claim": true,
  "auto_open_browser": true,
  "browser_path": null
}
```

- `captcha_relay` *(bool)*: Enables local web relay server for manual hCaptcha challenge solving.
- `relay_host` *(string)*: Host interface to bind relay server (`0.0.0.0` allows LAN and mobile access).
- `relay_port` *(int)*: Port for web relay (`8787`).
- `auto_claim` *(bool)*: Automatically claim rewards immediately upon 100% quest progress.
- `auto_open_browser` *(bool)*: Automatically pop open default browser (or phone browser via `termux-open-url` / `am start`).
- `browser_path` *(string/null)*: Optional explicit path to Chrome/Brave/Chromium binary for legacy CDP headless mirroring. When `null` (default), operates in ultra-fast, zero-latency **Direct Web Solver** mode across all devices.

### `tokens.txt`
Add one Discord user token per line. No quotes or commas:
```text
USER_TOKEN_1
USER_TOKEN_2
```

---

<div align="center">
  <img src="https://capsule-render.vercel.app/api?type=transparent&color=gradient&customColorList=9d4edd,3c096c&height=60&section=header&text=🤖%20AI%20Agent%20Operations%20Guide&fontSize=36&fontAlignY=35" alt="AI Agent Guide" />
</div>



---

<div align="center">
  <img src="https://capsule-render.vercel.app/api?type=transparent&color=gradient&customColorList=00e5ff,b500ff&height=60&section=header&text=👨‍💻%20About%20Developer&fontSize=38&fontAlignY=35" alt="About Developer" />
</div>

<div align="center">
  <p><b>GhoSty | Brutality (Async Development)</b></p>
  <a href="https://discord.com/users/940896719045034024" target="_blank">
    <img src="https://lanyard.cnrad.dev/api/940896719045034024?theme=dark&bg=16161a&animated=true&hideDiscrim=true&borderRadius=10px" alt="Live Discord Profile Widget" />
  </a>
</div>

---

<div align="center">
  <img src="https://capsule-render.vercel.app/api?type=transparent&color=gradient&customColorList=00ffaa,00e5ff&height=60&section=header&text=💖%20Support%20the%20Project&fontSize=38&fontAlignY=35" alt="Support" />
</div>

If GhoSty Quest Completor saved you hours of grind, consider supporting the project!

**Litecoin (LTC) Wallet:**
```text
LbeKrDeUF7mTB8LZLHkjicQfEW6tyhVGny
```

You can also donate directly via **[Donatree](https://donatr.ee/brutality/)**.

*Shoot `@jijaghosty` a DM on Discord with your transaction ID after donating to receive exclusive community perks!*

---

<div align="center">
  <i>Built with passion by GhoSty. Happy Questing! ❤</i>
  <br><br>
</div>
