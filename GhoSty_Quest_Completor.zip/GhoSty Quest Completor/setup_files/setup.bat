@echo off
title GhoSty Quest Completor - Setup Assistant
cd /d "%~dp0\.."
python setup.py
if errorlevel 1 (
    echo.
    echo [!] Setup exited with an error.
    pause
)
