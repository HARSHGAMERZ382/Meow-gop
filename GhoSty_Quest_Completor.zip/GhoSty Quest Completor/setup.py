import os
import sys
import subprocess
import time

def install_colorama():
    try:
        import colorama
    except ImportError:
        print("Installing colorama for colorful terminal output...")
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "colorama"],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

install_colorama()
from colorama import init, Fore, Style

init(autoreset=True)

class Colors:
    CYAN = Fore.CYAN
    GREEN = Fore.GREEN
    YELLOW = Fore.YELLOW
    RED = Fore.RED
    DIM = Style.DIM
    BOLD = Style.BRIGHT
    RESET = Style.RESET_ALL

def log_step(step_num, message):
    print(f"\n{Colors.CYAN}{Colors.BOLD}[ Step {step_num} ]{Colors.RESET} {Colors.BOLD}{message}{Colors.RESET}")

def log_info(message):
    print(f"{Colors.DIM} -> {message}{Colors.RESET}")

def log_success(message):
    print(f"{Colors.GREEN} -> {message}{Colors.RESET}")

def log_warn(message):
    print(f"{Colors.YELLOW} -> [!] {message}{Colors.RESET}")

def log_error(message):
    print(f"{Colors.RED} -> [X] {message}{Colors.RESET}")

def is_termux():
    return (
        "PREFIX" in os.environ and "com.termux" in os.environ.get("PREFIX", "")
    ) or "TERMUX_VERSION" in os.environ or "ANDROID_ROOT" in os.environ

def is_windows():
    return os.name == "nt"

def banner():
    print(rf"""
    {Colors.DIM}Welcome to GhoSty Quest Completor Setup Assistant{Colors.RESET}
    {Colors.DIM}Engineered for Windows, Linux, macOS, Android Termux & Cloud Containers{Colors.RESET}
{Colors.GREEN}{"="*65}{Colors.RESET}""")

def setup_dependencies():
    log_step(1, "Environment Preparation & Wheel Toolchain")

    if is_termux():
        log_info("Android Termux environment detected.")
        log_info("Installing native build toolchain & development headers...")
        subprocess.run("pkg update -y", shell=True)
        subprocess.run("pkg install x11-repo tur-repo -y", shell=True)
        subprocess.run("pkg install termux-tools -y", shell=True)

        termux_pkgs = (
            "clang make pkg-config libcurl openssl libffi "
            "python python-pip python-dev libxml2 libxslt"
        )
        subprocess.run(f"pkg install {termux_pkgs} -y", shell=True)
        subprocess.run("pkg install chromium -y || true", shell=True)

        log_info("Bootstrapping build systems (setuptools, wheel, cffi, cython)...")
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel", "cffi", "cython"],
            check=False,
        )

        log_info("Pre-compiling / building wheel for curl_cffi on Termux...")

        env = os.environ.copy()
        env["CFLAGS"] = f"-I{os.environ.get('PREFIX', '/data/data/com.termux/files/usr')}/include"
        env["LDFLAGS"] = f"-L{os.environ.get('PREFIX', '/data/data/com.termux/files/usr')}/lib"

        res = subprocess.run(
            [sys.executable, "-m", "pip", "install", "curl_cffi>=0.7.0", "--no-build-isolation"],
            env=env,
            check=False,
        )
        if res.returncode == 0:
            log_success("curl_cffi native wheel compiled and installed successfully on Termux.")
        else:
            log_warn("Standard build attempted; retrying with standard pip binary resolver...")
            subprocess.run([sys.executable, "-m", "pip", "install", "curl_cffi>=0.7.0"], check=False)

    requirements_file = "requirements.txt"
    if not os.path.exists(requirements_file):
        log_error(f"{requirements_file} not found! Cannot install dependencies.")
        return

    log_info("Installing all Python dependencies from requirements.txt...")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-r", requirements_file], check=True)
        log_success("All Python dependencies installed successfully.")
    except Exception as e:
        log_error(f"Failed to install requirements: {e}")

def verify_and_setup_tokens():
    log_step(2, "Token Configuration Setup")

    tokens_file = "tokens.txt"
    if not os.path.exists(tokens_file):
        log_warn(f"{tokens_file} not found. Creating a new template...")
        with open(tokens_file, "w", encoding="utf-8") as f:
            f.write("# Put your Discord tokens here (one per line)\n")
        existing_tokens = []
    else:
        with open(tokens_file, "r", encoding="utf-8") as f:
            existing_tokens = [line.strip() for line in f if line.strip() and not line.startswith("#")]

    if not existing_tokens:
        log_warn("tokens.txt has no tokens configured yet.")
        choice = input(f"{Colors.BOLD}Would you like to enter a Discord account token now? (y/N): {Colors.RESET}").strip().lower()
        if choice in ("y", "yes"):
            token_in = input(f"{Colors.CYAN}{Colors.BOLD}Enter Discord Token: {Colors.RESET}").strip()
            if (token_in.startswith('"') and token_in.endswith('"')) or (token_in.startswith("'") and token_in.endswith("'")):
                token_in = token_in[1:-1].strip()
            if token_in:
                with open(tokens_file, "a", encoding="utf-8") as f:
                    f.write(f"\n{token_in}")
                log_success("Token added to tokens.txt!")
            else:
                log_warn("Empty token entered. You can add tokens to tokens.txt manually later.")
        else:
            log_info("Skipped token entry. Remember to add tokens to tokens.txt before running.")
    else:
        log_success(f"Found {len(existing_tokens)} account token(s) configured in tokens.txt.")

def generate_launch_helpers():
    log_step(3, "Generating Launch Helper Scripts")

    setup_files_dir = "setup_files"
    os.makedirs(setup_files_dir, exist_ok=True)

    run_bat = os.path.join(setup_files_dir, "run.bat")
    with open(run_bat, "w", encoding="utf-8") as f:
        f.write("@echo off\n")
        f.write("title GhoSty Quest Completor\n")
        f.write('cd /d "%~dp0\\.."\n')
        f.write("python main.py\n")
        f.write("if errorlevel 1 (\n")
        f.write("    echo.\n")
        f.write("    echo [!] Program exited with an error. Check configuration or dependencies.\n")
        f.write("    pause\n")
        f.write(")\n")

    setup_bat = os.path.join(setup_files_dir, "setup.bat")
    with open(setup_bat, "w", encoding="utf-8") as f:
        f.write("@echo off\n")
        f.write("title GhoSty Quest Completor - Setup Assistant\n")
        f.write('cd /d "%~dp0\\.."\n')
        f.write("python setup.py\n")
        f.write("if errorlevel 1 (\n")
        f.write("    echo.\n")
        f.write("    echo [!] Setup exited with an error.\n")
        f.write("    pause\n")
        f.write(")\n")

    run_sh = os.path.join(setup_files_dir, "run.sh")
    with open(run_sh, "w", encoding="utf-8") as f:
        f.write("#!/usr/bin/env bash\n")
        f.write('PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"\n')
        f.write('cd "$PROJECT_DIR" || exit 1\n\n')
        f.write("if command -v python3 >/dev/null 2>&1; then\n")
        f.write('    python3 main.py "$@"\n')
        f.write("elif command -v python >/dev/null 2>&1; then\n")
        f.write('    python main.py "$@"\n')
        f.write("else\n")
        f.write('    echo "[!] Python is not installed or not in PATH."\n')
        f.write("    exit 1\n")
        f.write("fi\n")
    if not is_windows():
        try:
            os.chmod(run_sh, 0o755)
        except Exception:
            pass

    termux_sh = os.path.join(setup_files_dir, "termux_setup.sh")
    with open(termux_sh, "w", encoding="utf-8") as f:
        f.write("#!/data/data/com.termux/files/usr/bin/bash\n\n")
        f.write('if [ ! -d "/storage/emulated/0" ]; then\n')
        f.write('    echo -e "\\033[93m[!] Requesting storage access. Tap ALLOW on your phone screen.\\033[0m"\n')
        f.write("    termux-setup-storage\n")
        f.write("    sleep 3\n")
        f.write("fi\n\n")
        f.write("pkg update -y && pkg upgrade -y\n")
        f.write("pkg install x11-repo tur-repo -y\n")
        f.write("pkg install termux-tools -y\n")
        f.write("pkg install clang make pkg-config libcurl openssl libffi python python-pip -y\n")
        f.write("pkg install chromium -y || true\n\n")
        f.write("pip install --upgrade setuptools wheel packaging cffi cython\n\n")
        f.write('PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"\n')
        f.write('cd "$PROJECT_DIR" || exit 1\n\n')
        f.write('if [ -f "setup.py" ]; then\n')
        f.write("    python setup.py\n")
        f.write("else\n")
        f.write("    python3 setup.py\n")
        f.write("fi\n")
    if not is_windows():
        try:
            os.chmod(termux_sh, 0o755)
        except Exception:
            pass

    log_success(f"Launch helper scripts generated in {setup_files_dir}/")

def display_launch_instructions():
    log_step(4, "Ready to Launch & Execution Commands")

    print(f"{Colors.GREEN}{Colors.BOLD}Setup is complete! You can run GhoSty Quest Completor using the commands below:{Colors.RESET}\n")

    cwd = os.getcwd()
    run_bat_path = os.path.join(cwd, "setup_files", "run.bat")
    run_sh_path = os.path.join(cwd, "setup_files", "run.sh")
    termux_sh_path = os.path.join(cwd, "setup_files", "termux_setup.sh")

    if is_termux():
        print(f"  {Colors.CYAN}{Colors.BOLD}[Android (Termux) Run Command]:{Colors.RESET}")
        print(f"  {Colors.YELLOW}cd \"{cwd}\" && python main.py{Colors.RESET}\n")
        print(f"  {Colors.DIM}Or run helper:{Colors.RESET} {Colors.YELLOW}bash \"{run_sh_path}\"{Colors.RESET}\n")
    elif is_windows():
        print(f"  {Colors.CYAN}{Colors.BOLD}[Windows (CMD / PowerShell) Run Command]:{Colors.RESET}")
        print(f"  {Colors.YELLOW}cd /d \"{cwd}\" && python main.py{Colors.RESET}\n")
        print(f"  {Colors.DIM}Or double-click:{Colors.RESET} {Colors.YELLOW}{run_bat_path}{Colors.RESET}\n")
    else:
        print(f"  {Colors.CYAN}{Colors.BOLD}[Linux / macOS Run Command]:{Colors.RESET}")
        print(f"  {Colors.YELLOW}cd \"{cwd}\" && python3 main.py{Colors.RESET}\n")
        print(f"  {Colors.DIM}Or run:{Colors.RESET} {Colors.YELLOW}bash \"{run_sh_path}\"{Colors.RESET}\n")

def run_main_script():
    log_info("Starting GhoSty Quest Completor...")
    try:
        subprocess.run([sys.executable, "main.py"], check=False)
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}GhoSty Quest Completor stopped by user.{Colors.RESET}")
    except Exception as e:
        log_error(f"Error while running main.py: {e}")

def main():
    banner()
    setup_dependencies()
    verify_and_setup_tokens()
    generate_launch_helpers()
    display_launch_instructions()

    print(f"{Colors.BOLD}{Colors.GREEN}{'='*65}{Colors.RESET}")
    try:
        run_now = input(f"{Colors.BOLD}Would you like to start GhoSty Quest Completor right now? (Y/n): {Colors.RESET}").strip().lower()
        if run_now in ("", "y", "yes"):
            print()
            run_main_script()
        else:
            print(f"\n{Colors.CYAN}You can start the tool anytime using the commands shown above. Enjoy!{Colors.RESET}\n")
    except (KeyboardInterrupt, EOFError):
        print("\nExiting setup.")

if __name__ == "__main__":
    main()
