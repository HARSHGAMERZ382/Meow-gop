from __future__ import annotations

import asyncio
import json
from typing import Any, Dict, List, Optional, Tuple, TYPE_CHECKING

from discord.http import Route

try:
    from discord.errors import CaptchaRequired
except ImportError:
    CaptchaRequired = Exception

from .models import GhostyQuest, GhostyQuestUserStatus
from .security import GhostySecurityManager
from . import ui

if TYPE_CHECKING:
    from .utils import GhostyConfig
    from .relay import GhostyCaptchaRelay

GHOSTY_API_BASE = "https://discord.com/api/v10"

class GhostyCaptchaRequiredError(Exception):

    pass

class GhostyCaptchaChallengeException(Exception):

    def __init__(self, payload: Dict[str, Any]):
        super().__init__("Discord hCaptcha challenge required.")
        self.payload = payload
        self.sitekey = payload.get("captcha_sitekey") or "4bb5aadb-b50f-4f23-b1c2-92b59ba400d5"
        self.rqdata = payload.get("captcha_rqdata")
        self.rqtoken = payload.get("captcha_rqtoken")
        self.session_id = payload.get("captcha_session_id")

def extract_captcha_payload(err: Any) -> Optional[Dict[str, Any]]:

    if isinstance(err, dict) and ("captcha_key" in err or "captcha_sitekey" in err):
        return err

    for attr in ("json", "data", "payload"):
        val = getattr(err, attr, None)
        if isinstance(val, dict) and ("captcha_key" in val or "captcha_sitekey" in val):
            return val

    if hasattr(err, "sitekey") and getattr(err, "sitekey", None):
        return {
            "captcha_sitekey": getattr(err, "sitekey"),
            "captcha_rqdata": getattr(err, "rqdata", None),
            "captcha_rqtoken": getattr(err, "rqtoken", None),
            "captcha_session_id": getattr(err, "session_id", None),
        }

    for text_source in (getattr(err, "text", None), str(err)):
        if not text_source or not isinstance(text_source, str):
            continue
        if "captcha_key" in text_source or "captcha_sitekey" in text_source:
            start = text_source.find("{")
            end = text_source.rfind("}")
            if start != -1 and end != -1 and end > start:
                try:
                    parsed = json.loads(text_source[start : end + 1])
                    if isinstance(parsed, dict) and ("captcha_key" in parsed or "captcha_sitekey" in parsed):
                        return parsed
                except Exception:
                    pass

    return None

try:
    from curl_cffi.requests import AsyncSession as CurlAsyncSession
    HAVE_CURL_CFFI = True
except ImportError:
    CurlAsyncSession = None
    HAVE_CURL_CFFI = False

import aiohttp

class GhostyRestClient:

    def __init__(
        self,
        token: str,
        security: Optional[GhostySecurityManager] = None,
        http_client: Optional[Any] = None,
        config: Optional[GhostyConfig] = None,
        relay: Optional[GhostyCaptchaRelay] = None,
    ):
        self.token = token.strip()
        self.security = security or GhostySecurityManager()
        self.http_client = http_client
        self.config = config
        self.relay = relay
        self.use_curl = HAVE_CURL_CFFI
        self.curl_session: Optional[Any] = None
        self.aio_session: Optional[aiohttp.ClientSession] = None

    def ghosty_set_http_client(self, client: Any) -> None:
        self.http_client = client

    async def ghosty_init_fallback_session(self) -> None:
        headers = self.security.ghosty_get_http_headers(self.token)

        if self.use_curl and CurlAsyncSession is not None:
            if self.curl_session is None:
                self.curl_session = CurlAsyncSession(
                    impersonate="chrome120",
                    headers=headers,
                    timeout=30.0,
                )
        else:
            if self.aio_session is None or self.aio_session.closed:
                timeout = aiohttp.ClientTimeout(total=30.0, connect=10.0)
                connector = aiohttp.TCPConnector(ssl=True, ttl_dns_cache=300)
                self.aio_session = aiohttp.ClientSession(
                    headers=headers,
                    timeout=timeout,
                    connector=connector,
                )

    async def ghosty_close(self) -> None:
        if self.curl_session:
            await self.curl_session.close()
            self.curl_session = None
        if self.aio_session and not self.aio_session.closed:
            await self.aio_session.close()
            self.aio_session = None

    async def _ghosty_browser_request(
        self,
        method: str,
        path: str,
        json_data: Optional[dict] = None,
        extra_headers: Optional[dict] = None,
    ) -> Any:
        await self.ghosty_init_fallback_session()
        url = f"{GHOSTY_API_BASE}{path}"
        headers = self.security.ghosty_get_http_headers(self.token)
        if extra_headers:
            headers.update(extra_headers)

        req_kwargs: Dict[str, Any] = {"headers": headers}
        if json_data is not None:
            req_kwargs["json"] = json_data

        if self.use_curl and self.curl_session:
            resp = await self.curl_session.request(method, url, **req_kwargs)
            if resp.status_code not in (200, 204):
                try:
                    err_json = resp.json()
                    if isinstance(err_json, dict) and ("captcha_key" in err_json or "captcha_sitekey" in err_json):
                        raise GhostyCaptchaChallengeException(err_json)
                except GhostyCaptchaChallengeException:
                    raise
                except Exception:
                    pass
                raise RuntimeError(f"HTTP {resp.status_code}: {resp.text}")
            try:
                return resp.json()
            except Exception:
                return resp.text
        else:
            assert self.aio_session is not None
            async with self.aio_session.request(method, url, **req_kwargs) as resp:
                if resp.status not in (200, 204):
                    try:
                        err_json = await resp.json()
                        if isinstance(err_json, dict) and ("captcha_key" in err_json or "captcha_sitekey" in err_json):
                            raise GhostyCaptchaChallengeException(err_json)
                    except GhostyCaptchaChallengeException:
                        raise
                    except Exception:
                        pass
                    text = await resp.text()
                    raise RuntimeError(f"HTTP {resp.status}: {text}")
                try:
                    return await resp.json()
                except Exception:
                    return await resp.text()

    async def _ghosty_request(
        self, method: str, path: str, json_data: Optional[dict] = None
    ) -> Any:

        if "/quests" in path:
            return await self._ghosty_browser_request(method, path, json_data)

        if self.http_client is not None:
            route = Route(method, path)
            try:
                return await self.http_client.request(route, json=json_data)
            except CaptchaRequired as cap_err:
                cap_payload = {
                    "captcha_sitekey": getattr(cap_err, "sitekey", None) or (cap_err.json.get("captcha_sitekey") if hasattr(cap_err, "json") else None),
                    "captcha_rqdata": getattr(cap_err, "rqdata", None) or (cap_err.json.get("captcha_rqdata") if hasattr(cap_err, "json") else None),
                    "captcha_rqtoken": getattr(cap_err, "rqtoken", None) or (cap_err.json.get("captcha_rqtoken") if hasattr(cap_err, "json") else None),
                    "captcha_session_id": getattr(cap_err, "session_id", None) or (cap_err.json.get("captcha_session_id") if hasattr(cap_err, "json") else None),
                }
                raise GhostyCaptchaChallengeException(cap_payload) from cap_err
            except Exception as e:
                cap_payload = extract_captcha_payload(e)
                if cap_payload:
                    raise GhostyCaptchaChallengeException(cap_payload) from e
                raise

        return await self._ghosty_browser_request(method, path, json_data)

    async def ghosty_fetch_quests(self) -> List[GhostyQuest]:
        data = await self._ghosty_request("GET", "/quests/@me")
        quests_list = data.get("quests", []) if isinstance(data, dict) else data
        return [GhostyQuest(q) for q in quests_list]

    async def ghosty_get_user_quest(self, quest_id: str) -> Optional[GhostyQuest]:

        quests = await self.ghosty_fetch_quests()
        for q in quests:
            if q.id == quest_id:
                return q
        return None

    async def ghosty_get_quest(self, quest_id: str) -> GhostyQuest:
        data = await self._ghosty_request("GET", f"/quests/{quest_id}")
        return GhostyQuest(data)

    async def ghosty_fetch_claimed_quests(self) -> List[dict]:
        try:
            data = await self._ghosty_request("GET", "/quests/@me/claimed")
            return data.get("quests", []) if isinstance(data, dict) else data
        except Exception:
            return []

    async def ghosty_enroll(self, quest_id: str, location: int = 11) -> GhostyQuestUserStatus:
        data = await self._ghosty_request(
            "POST", f"/quests/{quest_id}/enroll", json_data={"location": location}
        )
        return GhostyQuestUserStatus(data)

    async def ghosty_send_heartbeat(
        self,
        quest_id: str,
        application_id: str,
        stream_key: Optional[str] = None,
        terminal: bool = False,
    ) -> GhostyQuestUserStatus:
        payload: Dict[str, Any] = {"application_id": application_id}
        if stream_key:
            payload["stream_key"] = stream_key
        if terminal:
            payload["terminal"] = True

        data = await self._ghosty_request(
            "POST", f"/quests/{quest_id}/heartbeat", json_data=payload
        )
        return GhostyQuestUserStatus(data)

    async def ghosty_send_video_progress(
        self, quest_id: str, timestamp: int
    ) -> GhostyQuestUserStatus:
        data = await self._ghosty_request(
            "POST", f"/quests/{quest_id}/video-progress", json_data={"timestamp": timestamp}
        )
        return GhostyQuestUserStatus(data)

    async def ghosty_claim_reward(
        self,
        quest_id: str,
        platform: int = 0,
        location: int = 10,
        traffic_metadata_sealed: Optional[str] = None,
        metadata_sealed: Optional[str] = None,
        decision_id: Optional[str] = None,
        quest_name: str = "Discord Quest",
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "location": location,
            "platform": platform,
            "is_targeted": False,
        }
        if decision_id:
            payload["decision_id"] = decision_id
        if metadata_sealed:
            payload["metadata_sealed"] = metadata_sealed
            payload["provenance_metadata_sealed"] = metadata_sealed
        if traffic_metadata_sealed:
            payload["traffic_metadata_sealed"] = traffic_metadata_sealed

        cap_payload: Optional[Dict[str, Any]] = None
        try:
            data = await self._ghosty_browser_request(
                "POST", f"/quests/{quest_id}/claim-reward", json_data=payload
            )
            return data if isinstance(data, dict) else {}
        except GhostyCaptchaChallengeException as cce:
            cap_payload = cce.payload
        except CaptchaRequired as cap_err:
            cap_payload = {
                "captcha_sitekey": getattr(cap_err, "sitekey", None) or (cap_err.json.get("captcha_sitekey") if hasattr(cap_err, "json") else None),
                "captcha_rqdata": getattr(cap_err, "rqdata", None) or (cap_err.json.get("captcha_rqdata") if hasattr(cap_err, "json") else None),
                "captcha_rqtoken": getattr(cap_err, "rqtoken", None) or (cap_err.json.get("captcha_rqtoken") if hasattr(cap_err, "json") else None),
                "captcha_session_id": getattr(cap_err, "session_id", None) or (cap_err.json.get("captcha_session_id") if hasattr(cap_err, "json") else None),
            }
        except Exception as e:
            cap_payload = extract_captcha_payload(e)
            if not cap_payload:
                raise

        if cap_payload:
            sitekey = cap_payload.get("captcha_sitekey") or "4bb5aadb-b50f-4f23-b1c2-92b59ba400d5"
            rqdata = cap_payload.get("captcha_rqdata")
            rqtoken = cap_payload.get("captcha_rqtoken")
            session_id = cap_payload.get("captcha_session_id")

            if self.config and self.config.captcha_relay and self.relay:
                ui.log_info(f"Discord issued hCaptcha challenge for '{quest_name}'. Starting interactive relay...")
                solved = await self.relay.async_solve(
                    sitekey=sitekey,
                    rqdata=rqdata,
                    rqtoken=rqtoken,
                    token=self.token,
                    quest_name=quest_name,
                )
                if solved:
                    ui.log_success("Captcha solved successfully! Submitting verified claim to Discord...")
                    extra_headers = {"X-Captcha-Key": solved}
                    if session_id:
                        extra_headers["X-Captcha-Session-Id"] = session_id
                    if rqtoken:
                        extra_headers["X-Captcha-Rqtoken"] = rqtoken

                    try:
                        res = await self._ghosty_browser_request(
                            "POST",
                            f"/quests/{quest_id}/claim-reward",
                            json_data=payload,
                            extra_headers=extra_headers,
                        )

                        code = None
                        if isinstance(res, dict) and res.get("code"):
                            code = res.get("code")
                        else:
                            code = await self.ghosty_get_reward_code(quest_id)

                        if self.relay:
                            self.relay.mark_claimed(quest_name=quest_name, promo_code=code or "")
                        return res if isinstance(res, dict) else {}
                    except Exception as submit_err:
                        ui.log_warn(f"Claim retry rejected: {submit_err}")
                        if self.relay:
                            self.relay.mark_failed(str(submit_err))
                else:
                    ui.log_warn("Captcha solving was cancelled or timed out.")

            raise GhostyCaptchaRequiredError("Discord hCaptcha challenge required.")

        return {}

    async def ghosty_get_reward_code(self, quest_id: str) -> Optional[str]:
        try:
            data = await self._ghosty_request("GET", f"/quests/{quest_id}/reward-code")
            if isinstance(data, dict):
                return data.get("code")
        except Exception:
            pass
        return None
