from __future__ import annotations

import asyncio
import random
import time
from typing import Callable, Optional

from .gateway import GhostyGatewayManager
from .models import GhostyQuest
from .rest import GhostyRestClient, GhostyCaptchaRequiredError
from .security import GhostySecurityManager
from . import ui

class GhostyQuestHeart:

    HEARTBEAT_MIN = 61.0
    HEARTBEAT_MAX = 67.0
    HEARTBEAT_JITTER = 3.0

    VIDEO_STEP_MIN = 10
    VIDEO_STEP_MAX = 15
    VIDEO_INTERVAL_MIN = 11.0
    VIDEO_INTERVAL_MAX = 14.0

    def __init__(
        self,
        rest: GhostyRestClient,
        gateway: GhostyGatewayManager,
        security: Optional[GhostySecurityManager] = None,
    ):
        self.rest = rest
        self.gateway = gateway
        self.security = security or GhostySecurityManager()

    async def ghosty_execute_play_quest(
        self, quest: GhostyQuest, on_tick: Optional[Callable[[int, int], None]] = None
    ) -> bool:

        if quest.is_expired:
            ui.log_error(
                f"Cannot progress '{quest.config.quest_name}': Quest campaign expired on {quest.config.expires_at}."
            )
            return False

        task_type = quest.primary_task_type
        target = quest.target_seconds
        app_id = quest.config.application_id or (
            quest.config.ghosty_get_application_ids(task_type)[0]
            if quest.config.ghosty_get_application_ids(task_type)
            else ""
        )
        game_name = quest.config.game_title

        ui.log_info(f"Target Quest: {quest.config.quest_name} ({game_name})")
        ui.log_info(f"Required Target: {target}s | Application ID: {app_id} | {quest.expires_in_display}")

        if self.gateway.is_connected:
            ui.log_info(f"Broadcasting Rich Presence on Gateway for '{game_name}' (Opcode 3)...")
            await self.gateway.ghosty_sync_game_presence(app_id, game_name)
        else:
            ui.log_warn("Gateway not connected. Running heartbeat in REST fallback mode...")

        if not quest.enrolled:
            ui.log_info(f"Enrolling in quest '{quest.config.quest_name}'...")
            try:
                await self.rest.ghosty_enroll(quest.id)
                await asyncio.sleep(self.security.ghosty_generate_jitter(2.0, 4.0, 1.0))
            except Exception as e:
                ui.log_error(f"Failed to enroll in quest: {e}")
                return False

        elapsed = quest.current_progress_seconds
        server_completed = False

        try:
            while not server_completed and elapsed < target:
                wait_time = self.security.ghosty_generate_jitter(
                    self.HEARTBEAT_MIN, self.HEARTBEAT_MAX, self.HEARTBEAT_JITTER
                )

                ui.log_heartbeat(elapsed, target, wait_time)

                if on_tick:
                    on_tick(elapsed, target)

                await asyncio.sleep(wait_time)
                elapsed += int(wait_time)
                is_terminal = elapsed >= target

                try:
                    status = await self.rest.ghosty_send_heartbeat(
                        quest.id,
                        application_id=app_id,
                        terminal=is_terminal,
                    )
                    server_val = status.ghosty_get_progress_value(task_type)
                    if server_val > 0:
                        elapsed = server_val

                    if status.is_completed:
                        server_completed = True
                        ui.log_success(f"Discord server confirmed quest completion for '{quest.config.quest_name}'!")
                        break
                    elif server_val >= target:
                        server_completed = True
                        ui.log_success(f"Discord server marked target {target}s reached for '{quest.config.quest_name}'!")
                        break
                except Exception as err:
                    elapsed = max(0, elapsed - int(wait_time))
                    err_msg = str(err)

                    if "260017" in err_msg or "Quest has expired" in err_msg or "404" in err_msg:
                        ui.log_error(f"Discord server rejected heartbeat: Quest has expired or is invalid. Aborting.")
                        return False
                    ui.log_warn(f"Heartbeat transient exception: {err}. Retrying in next cycle...")
                    await asyncio.sleep(random.uniform(5.0, 10.0))

            if not server_completed:
                try:
                    refreshed = await self.rest.ghosty_get_user_quest(quest.id)
                    if refreshed and refreshed.completed:
                        server_completed = True
                except Exception:
                    pass

            if server_completed:
                ui.log_success(f"Quest Finished Successfully: {quest.config.quest_name}")
                return True
            else:
                ui.log_warn(f"Finished runner but Discord has not marked completion yet.")
                return False

        finally:
            if self.gateway.is_connected:
                ui.log_info("Clearing Rich Presence from Gateway session...")
                await self.gateway.ghosty_clear_presence()

    async def ghosty_execute_video_quest(self, quest: GhostyQuest) -> bool:

        if quest.is_expired:
            ui.log_error(
                f"Cannot progress '{quest.config.quest_name}': Quest campaign expired on {quest.config.expires_at}."
            )
            return False

        target = quest.target_seconds
        ui.log_info(f"Target Video Quest: {quest.config.quest_name}")
        ui.log_info(f"Video Target Length: {target} seconds | {quest.expires_in_display}")

        if not quest.enrolled:
            ui.log_info("Enrolling in video quest...")
            try:
                await self.rest.ghosty_enroll(quest.id)
                await asyncio.sleep(self.security.ghosty_generate_jitter(2.0, 4.0, 1.0))
            except Exception as e:
                ui.log_error(f"Failed to enroll in video quest: {e}")
                return False

        position = quest.current_progress_seconds
        server_completed = False

        while position < target:
            step = random.randint(self.VIDEO_STEP_MIN, self.VIDEO_STEP_MAX)
            position = min(position + step, target)
            interval = random.uniform(self.VIDEO_INTERVAL_MIN, self.VIDEO_INTERVAL_MAX)

            ui.log_video_tick(position, target, step, interval)
            await asyncio.sleep(interval)

            try:
                status = await self.rest.ghosty_send_video_progress(quest.id, position)
                server_val = status.ghosty_get_progress_value(quest.primary_task_type)
                if server_val > 0:
                    position = max(position, server_val)
                if status.is_completed or position >= target:
                    server_completed = True
                    ui.log_success(f"Video quest '{quest.config.quest_name}' finalized on server!")
                    break
            except Exception as err:
                position = max(0, position - step)
                err_msg = str(err)
                if "260017" in err_msg or "Quest has expired" in err_msg or "404" in err_msg:
                    ui.log_error("Discord server rejected progress: Quest expired or invalid. Aborting.")
                    return False
                ui.log_warn(f"Video progress warning: {err}")
                await asyncio.sleep(random.uniform(4.0, 8.0))

        if not server_completed:
            try:
                refreshed = await self.rest.ghosty_get_user_quest(quest.id)
                if refreshed and refreshed.completed:
                    server_completed = True
            except Exception:
                pass

        if server_completed:
            ui.log_success(f"Video Quest Completed: {quest.config.quest_name}")
            return True
        return False

    async def ghosty_claim_reward(self, quest: GhostyQuest) -> bool:

        if quest.claimed:
            ui.log_info(f"Quest '{quest.config.quest_name}' reward is already claimed on your account.")
            return True

        if quest.is_expired and not quest.completed:
            ui.log_error(f"Cannot claim '{quest.config.quest_name}': Quest is expired and was not completed.")
            return False

        ui.log_info(f"Redeeming reward for '{quest.config.quest_name}'...")
        try:
            res = await self.rest.ghosty_claim_reward(
                quest.id,
                location=10,
                platform=0,
                traffic_metadata_sealed=quest.traffic_metadata_sealed,
                metadata_sealed=quest.metadata_sealed,
                quest_name=quest.config.quest_name,
            )
            ui.log_success(f"Reward redeemed successfully for '{quest.config.quest_name}'")

            code = await self.rest.ghosty_get_reward_code(quest.id)
            if code:
                ui.log_reward_code(quest.config.quest_name, code)
            if self.rest.relay:
                self.rest.relay.mark_claimed(quest_name=quest.config.quest_name, promo_code=code or "")
            return True

        except GhostyCaptchaRequiredError:

            try:
                refreshed = await self.rest.ghosty_get_user_quest(quest.id)
                if refreshed and refreshed.claimed:
                    ui.log_success(f"Reward confirmed CLAIMED on server for '{quest.config.quest_name}'!")
                    return True
            except Exception:
                pass
            ui.log_captcha_notice(quest.config.quest_name)
            return False

        except Exception as e:
            err_str = str(e)
            if "captcha" in err_str.lower() or "hcaptcha" in err_str.lower():
                try:
                    refreshed = await self.rest.ghosty_get_user_quest(quest.id)
                    if refreshed and refreshed.claimed:
                        ui.log_success(f"Reward confirmed CLAIMED on server for '{quest.config.quest_name}'!")
                        return True
                except Exception:
                    pass
                ui.log_captcha_notice(quest.config.quest_name)
                return False

            ui.log_error(f"Failed to claim reward for '{quest.config.quest_name}': {e}")
            return False

    async def ghosty_solve_quest(self, quest: GhostyQuest) -> bool:

        if quest.is_expired:
            ui.log_error(f"Quest '{quest.config.quest_name}' expired on {quest.config.expires_at}. Skipping.")
            return False

        if quest.completed:
            ui.log_info(f"Quest '{quest.config.quest_name}' is already completed on server.")
            if not quest.claimed:
                await self.ghosty_claim_reward(quest)
            return True

        task_type = quest.primary_task_type
        success = False
        if "WATCH_VIDEO" in task_type:
            success = await self.ghosty_execute_video_quest(quest)
        elif "PLAY" in task_type or "STREAM" in task_type:
            success = await self.ghosty_execute_play_quest(quest)
        else:
            ui.log_warn(f"Task type '{task_type}' defaulting to heartbeat runner...")
            success = await self.ghosty_execute_play_quest(quest)

        if success:
            await asyncio.sleep(random.uniform(2.5, 4.5))
            await self.ghosty_claim_reward(quest)
            return True

        return False
