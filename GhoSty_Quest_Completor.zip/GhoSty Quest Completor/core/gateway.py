from __future__ import annotations

import asyncio
import time
from typing import Optional, TYPE_CHECKING

import discord

if TYPE_CHECKING:
    from .utils import GhostyConfig
    from .relay import GhostyCaptchaRelay
from .rest import GhostyCaptchaRequiredError

class GhostyGatewayClient(discord.Client):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.ready_event = asyncio.Event()

    async def on_ready(self):
        self.ready_event.set()

class GhostyGatewayManager:

    def __init__(
        self,
        token: str,
        config: Optional[GhostyConfig] = None,
        relay: Optional[GhostyCaptchaRelay] = None,
    ):
        self.token = token.strip()
        self.config = config
        self.relay = relay
        self.client: Optional[GhostyGatewayClient] = None
        self._bg_task: Optional[asyncio.Task] = None
        self.is_connected = False

    @property
    def http(self):
        return self.client.http if self.client else None

    @property
    def username(self) -> str:
        if self.client and self.client.user:
            return str(self.client.user.name)
        return ""

    async def ghosty_connect(self, timeout: float = 15.0) -> bool:

        try:
            self.client = GhostyGatewayClient()

            if self.config and self.config.captcha_relay and self.relay:
                relay_inst = self.relay
                user_token = self.token

                async def _relay_captcha_handler(e) -> str:
                    sitekey = getattr(e, "sitekey", None) or (e.json.get("captcha_sitekey") if hasattr(e, "json") else "4c672d35-0701-42b2-88c3-78380b0db560")
                    rqdata = getattr(e, "rqdata", None) or (e.json.get("captcha_rqdata") if hasattr(e, "json") else None)
                    rqtoken = getattr(e, "rqtoken", None) or (e.json.get("captcha_rqtoken") if hasattr(e, "json") else None)

                    solved = await relay_inst.async_solve(
                        sitekey=sitekey,
                        rqdata=rqdata,
                        rqtoken=rqtoken,
                        token=user_token,
                        quest_name="Discord Quest Reward",
                    )
                    if not solved:
                        raise GhostyCaptchaRequiredError("Captcha resolution cancelled or timed out.")
                    return solved

                self.client.http.captcha_handler = _relay_captcha_handler

            self._bg_task = asyncio.create_task(self.client.start(self.token))
            await asyncio.wait_for(self.client.ready_event.wait(), timeout=timeout)
            self.is_connected = True
            return True
        except asyncio.TimeoutError:
            self.is_connected = False
            return False
        except Exception:
            self.is_connected = False
            return False

    async def ghosty_sync_game_presence(self, application_id: str, game_name: str) -> None:

        if not self.client or not self.client.is_ready():
            return

        try:
            app_id_int = int(application_id) if application_id.isdigit() else None
            activity = discord.Activity(
                type=discord.ActivityType.playing,
                name=game_name,
                application_id=app_id_int,
                timestamps={"start": int(time.time() * 1000)},
            )
            await self.client.change_presence(activity=activity, status=discord.Status.online)
        except Exception:
            pass

    async def ghosty_clear_presence(self) -> None:

        if self.client and self.client.is_ready():
            try:
                await self.client.change_presence(activity=None, status=discord.Status.online)
            except Exception:
                pass

    async def ghosty_disconnect(self) -> None:

        if self.client and not self.client.is_closed():
            await self.ghosty_clear_presence()
            await self.client.close()
        if self._bg_task and not self._bg_task.done():
            self._bg_task.cancel()
        self.is_connected = False
