from __future__ import annotations

import ctypes
import os
import re
import shutil
import sys
import time
from typing import Any, List, Optional, Tuple

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
if hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

def _enable_windows_vt():
    if os.name == "nt":
        try:
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.GetStdHandle(-11)
            mode = ctypes.c_ulong()
            if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                mode.value |= 0x0004
                kernel32.SetConsoleMode(handle, mode)
        except Exception:
            pass

_enable_windows_vt()

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
ITALIC = "\033[3m"

CYAN_ELECTRIC = (0, 245, 255)
CYAN_MID = (0, 195, 255)
BLUE_ELECTRIC = (30, 144, 255)
BLUE_NEON = (59, 130, 246)
PURPLE_NEON = (168, 85, 247)
PURPLE_LIGHT = (192, 132, 252)
GREEN_NEON = (52, 211, 153)
GREEN_EMERALD = (16, 185, 129)
YELLOW_GOLD = (250, 204, 21)
RED_CRIMSON = (248, 113, 113)
RED_BRIGHT = (239, 68, 68)
GRAY_TEXT = (148, 163, 184)
GRAY_MUTED = (100, 116, 139)
GRAY_BORDER = (51, 65, 85)
WHITE_BRIGHT = (248, 250, 252)

def fg_rgb(r: int, g: int, b: int) -> str:
    return f"\033[38;2;{r};{g};{b}m"

def bg_rgb(r: int, g: int, b: int) -> str:
    return f"\033[48;2;{r};{g};{b}m"

def strip_ansi(text: str) -> str:
    return re.sub(r"\033\[[0-9;]*[a-zA-Z]", "", text)

def get_term_width(default: int = 88) -> int:
    try:
        w = shutil.get_terminal_size((default, 24)).columns
        return max(w, 64)
    except Exception:
        return default

def clear_screen():
    if os.name == "nt":
        os.system("cls")
    else:
        sys.stdout.write("\033[2J\033[H\033[3J")
        sys.stdout.flush()

def center(text: str, width: Optional[int] = None) -> str:
    if width is None:
        width = get_term_width()
    plain_len = len(strip_ansi(text))
    if plain_len >= width:
        return text
    pad = (width - plain_len) // 2
    return " " * pad + text

def center_block(lines: List[str], width: Optional[int] = None) -> List[str]:
    if width is None:
        width = get_term_width()
    clean_lines = [strip_ansi(l) for l in lines]
    non_empty = [l for l in clean_lines if l.strip()]
    if not non_empty:
        return lines
    max_len = max(len(l) for l in non_empty)
    pad = max(0, (width - max_len) // 2)
    return [(" " * pad + line) if line.strip() else "" for line in lines]

def lerp_color(c1: Tuple[int, int, int], c2: Tuple[int, int, int], t: float) -> Tuple[int, int, int]:
    return (
        int(c1[0] + (c2[0] - c1[0]) * t),
        int(c1[1] + (c2[1] - c1[1]) * t),
        int(c1[2] + (c2[2] - c1[2]) * t),
    )

def multi_gradient_color(colors: List[Tuple[int, int, int]], t: float) -> Tuple[int, int, int]:
    if not colors:
        return (255, 255, 255)
    if len(colors) == 1 or t <= 0.0:
        return colors[0]
    if t >= 1.0:
        return colors[-1]

    seg_len = 1.0 / (len(colors) - 1)
    seg_idx = min(int(t / seg_len), len(colors) - 2)
    local_t = (t - (seg_idx * seg_len)) / seg_len
    return lerp_color(colors[seg_idx], colors[seg_idx + 1], local_t)

def colorize_gradient(text: str, colors: Optional[List[Tuple[int, int, int]]] = None) -> str:
    if colors is None:
        colors = [CYAN_ELECTRIC, CYAN_MID, BLUE_ELECTRIC, PURPLE_NEON]

    clean = strip_ansi(text)
    if not clean:
        return text

    n = len(clean)
    result = []
    clean_idx = 0
    in_ansi = False
    ansi_buf: List[str] = []

    for ch in text:
        if ch == "\033":
            in_ansi = True
            ansi_buf.append(ch)
            continue
        if in_ansi:
            ansi_buf.append(ch)
            if ch.isalpha():
                in_ansi = False
                result.append("".join(ansi_buf))
                ansi_buf = []
            continue

        t = clean_idx / max(n - 1, 1)
        r, g, b = multi_gradient_color(colors, t)
        result.append(f"{fg_rgb(r, g, b)}{ch}")
        clean_idx += 1

    result.append(RESET)
    return "".join(result)

LOGO_GHOSTY_QUEST = [
    "   ▄▄▄▄▄▄ ▄▄▄            ▄▄▄▄▄              ",
    " ██▀▀  ▀█  ██           ▄██ ▀█  ▄█           ",
    "███        ██▀██  ██▀█▄  ▀██▄▄ ▀██▀▀██▀▀█▀   ",
    "▀██   ▀██▀ ██ ██ ███ ██ ▄  ▀▀██ ██  ▀███     ",
    " ▀▀█▄▄▄█▀ ▄██▄██▄ ██▄█▀ █▀█▄▄█▀ ██▄  ▀█      ",
    "                                   ▄▄▄▀      ",
    "                                   ▀▀▀       ",
    "   ▄▄▄▄▄▄                                    ",
    "  ██▀  ▀██                          ▄█       ",
    " ███    ███ ██   ██  ▄████▄  ▄███▄ ▀██▀▀     ",
    " ▀██    ██▀ ██   ██ ██▄▄▄██  ▀▀██▄  ██       ",
    "  ▀██▄▄███▄ ▀██████  ▀██▄▄▄ █▄▄▄█▀  ██▄      ",
    "         ▀█                                  ",
]

def render_header(
    token_count: int,
    active_account: str,
    gateway_connected: bool,
    active_quests_count: int = 0,
    relay_enabled: bool = True,
    relay_port: int = 8787,
    width: Optional[int] = None,
) -> str:
    if width is None:
        width = get_term_width()

    lines_out = [""]
    grad_colors = [CYAN_ELECTRIC, (45, 190, 255), BLUE_ELECTRIC, PURPLE_NEON]
    banner_grad = [colorize_gradient(l, grad_colors) for l in LOGO_GHOSTY_QUEST]
    lines_out.extend(center_block(banner_grad, width))
    lines_out.append("")

    v_tag = (
        f"{fg_rgb(*CYAN_MID)}{BOLD}GhoSty Quest Completor{RESET} "
        f"{fg_rgb(*GRAY_MUTED)}•{RESET} {fg_rgb(*PURPLE_LIGHT)}Ultra-Secure Build (2026.11){RESET} "
        f"{fg_rgb(*GRAY_MUTED)}•{RESET} {fg_rgb(*GREEN_NEON)}{BOLD}Free Forever{RESET}"
    )
    lines_out.append(center(v_tag, width))
    lines_out.append("")

    gw_status = (
        f"{fg_rgb(*GREEN_NEON)}ONLINE (OPCODE 3){RESET}"
        if gateway_connected
        else f"{fg_rgb(*YELLOW_GOLD)}REST-ONLY{RESET}"
    )
    act_str = f"{fg_rgb(*WHITE_BRIGHT)}@{active_account}{RESET}" if active_account else f"{fg_rgb(*GRAY_MUTED)}NONE{RESET}"
    relay_str = (
        f"{fg_rgb(*PURPLE_LIGHT)}ONLINE (PORT: {relay_port}){RESET}"
        if relay_enabled
        else f"{fg_rgb(*GRAY_MUTED)}DISABLED{RESET}"
    )

    meta_line = (
        f"{fg_rgb(*GRAY_TEXT)}ACCOUNTS: {RESET}{fg_rgb(*CYAN_ELECTRIC)}<{token_count}>{RESET}  "
        f"{fg_rgb(*GRAY_BORDER)}│{RESET}  {fg_rgb(*GRAY_TEXT)}ACTIVE: {RESET}{act_str}  "
        f"{fg_rgb(*GRAY_BORDER)}│{RESET}  {fg_rgb(*GRAY_TEXT)}GATEWAY: {RESET}{gw_status}  "
        f"{fg_rgb(*GRAY_BORDER)}│{RESET}  {fg_rgb(*GRAY_TEXT)}RELAY: {RESET}{relay_str}"
    )
    lines_out.append(center(meta_line, width))

    author_line = (
        f"{fg_rgb(*GRAY_MUTED)}< Crafted With {RESET}{fg_rgb(*RED_CRIMSON)}♥{RESET}{fg_rgb(*GRAY_MUTED)} by {RESET}"
        f"{fg_rgb(*CYAN_MID)}{BOLD}@jijaghosty{RESET}{fg_rgb(*GRAY_MUTED)} • {RESET}"
        f"{fg_rgb(*PURPLE_NEON)}🇮🇳 Async Development{RESET}{fg_rgb(*GRAY_MUTED)} >{RESET}"
    )
    lines_out.append(center(author_line, width))
    lines_out.append("")

    box_lines = render_command_matrix(width=width)
    lines_out.extend(box_lines)
    lines_out.append("")

    div_title = f" {BOLD}{fg_rgb(*CYAN_ELECTRIC)}[ TERMINAL CONTROL MATRIX ]{RESET} "
    div_plain_len = len(strip_ansi(div_title))
    box_w = min(width - 4, 88)
    left_line_len = 4
    right_line_len = max(0, box_w - left_line_len - div_plain_len)
    section_div = f"{fg_rgb(*GRAY_BORDER)}{'─' * left_line_len}{RESET}{div_title}{fg_rgb(*GRAY_BORDER)}{'─' * right_line_len}{RESET}"
    lines_out.append(center(section_div, width))
    lines_out.append("")

    return "\n".join(lines_out)

def render_command_matrix(width: Optional[int] = None) -> List[str]:
    if width is None:
        width = get_term_width()

    box_w = min(width - 4, 88)
    if box_w < 64:
        box_w = 64

    b_col = fg_rgb(*CYAN_MID)
    tag_col = fg_rgb(*CYAN_ELECTRIC)

    col1 = [
        ("<01>", "List Quests", "Show active list"),
        ("<02>", "Solve Single", "Pick by quest #"),
        ("<03>", "Auto-Solve All", "Solve incomplete"),
    ]
    col2 = [
        ("<04>", "Filter (Play)", "Solve game quests"),
        ("<05>", "Filter (Video)", "Solve video quests"),
        ("<06>", "Claim Rewards", "Redeem completed"),
    ]
    col3 = [
        ("<07>", "Switch Account", "Switch user token"),
        ("<08>", "Add Token", "Add new to list"),
        ("<09>", "Exit Suite", "Graceful shutdown"),
    ]

    col_w = (box_w - 4) // 3
    lines: List[str] = []

    top_border = f"{b_col}╭{'─' * (box_w - 2)}╮{RESET}"
    lines.append(center(top_border, width))

    title_text = f"{BOLD}{fg_rgb(*WHITE_BRIGHT)}AVAILABLE ACTIONS{RESET}"
    inner_pad = (box_w - 2 - len(strip_ansi(title_text))) // 2
    right_pad = box_w - 2 - len(strip_ansi(title_text)) - inner_pad
    lines.append(center(f"{b_col}│{RESET}{' ' * inner_pad}{title_text}{' ' * right_pad}{b_col}│{RESET}", width))

    sep_border = f"{b_col}├{'─' * (box_w - 2)}┤{RESET}"
    lines.append(center(sep_border, width))

    for r in range(3):
        c1_num, c1_cmd, _ = col1[r]
        c2_num, c2_cmd, _ = col2[r]
        c3_num, c3_cmd, _ = col3[r]

        c1_str = f"{tag_col}{c1_num}{RESET} {fg_rgb(*WHITE_BRIGHT)}{c1_cmd:<15}{RESET}"
        c2_str = f"{tag_col}{c2_num}{RESET} {fg_rgb(*WHITE_BRIGHT)}{c2_cmd:<15}{RESET}"
        c3_str = f"{tag_col}{c3_num}{RESET} {fg_rgb(*WHITE_BRIGHT)}{c3_cmd:<14}{RESET}"

        raw_c1 = len(strip_ansi(c1_str))
        raw_c2 = len(strip_ansi(c2_str))

        row_content = (
            f" {c1_str}{' ' * max(0, col_w - raw_c1)}"
            f"{b_col}│{RESET} {c2_str}{' ' * max(0, col_w - raw_c2)}"
            f"{b_col}│{RESET} {c3_str}"
        )
        r_pad = max(0, box_w - 2 - len(strip_ansi(row_content)))
        lines.append(center(f"{b_col}│{RESET}{row_content}{' ' * r_pad}{b_col}│{RESET}", width))

    bottom_border = f"{b_col}╰{'─' * (box_w - 2)}╯{RESET}"
    lines.append(center(bottom_border, width))
    return lines

def make_badge(text: str, bg_tuple: Tuple[int, int, int], fg_tuple: Tuple[int, int, int] = (0, 0, 0), width: int = 10) -> str:
    padded = f" {text} ".center(width)
    return f"{bg_rgb(*bg_tuple)}{fg_rgb(*fg_tuple)}{BOLD}{padded}{RESET}"

def log_info(msg: str):
    badge = make_badge("INFO", (14, 165, 233), (0, 0, 0), width=10)
    arrow = f"{fg_rgb(*CYAN_MID)}──>{RESET}"
    print(f"   {badge} {arrow} {fg_rgb(*WHITE_BRIGHT)}{msg}{RESET}")

def log_success(msg: str):
    badge = make_badge("SUCCESS", (16, 185, 129), (0, 0, 0), width=10)
    arrow = f"{fg_rgb(*GREEN_NEON)}──>{RESET}"
    print(f"   {badge} {arrow} {fg_rgb(*GREEN_NEON)}{msg}{RESET}")

def log_warn(msg: str):
    badge = make_badge("WARNING", (217, 119, 6), (0, 0, 0), width=10)
    arrow = f"{fg_rgb(*YELLOW_GOLD)}──>{RESET}"
    print(f"   {badge} {arrow} {fg_rgb(*YELLOW_GOLD)}{msg}{RESET}")

def log_error(msg: str):
    badge = make_badge("ERROR", (220, 38, 38), (255, 255, 255), width=10)
    arrow = f"{fg_rgb(*RED_BRIGHT)}──>{RESET}"
    print(f"   {badge} {arrow} {fg_rgb(248, 113, 113)}{msg}{RESET}")

def log_heartbeat(current: int, target: int, next_wait: float):
    pct = min(100.0, (current / max(1, target)) * 100)
    badge = make_badge("HEARTBEAT", (99, 102, 241), (255, 255, 255), width=11)
    tag = f"{fg_rgb(*CYAN_ELECTRIC)}[{current:>4}/{target:<4}s ({pct:>5.1f}%)]"
    arrow = f"{fg_rgb(*BLUE_ELECTRIC)}──>{RESET}"
    msg = f"{fg_rgb(*WHITE_BRIGHT)}Next pulse in {next_wait:.1f}s (Jitter applied){RESET}"
    print(f"   {badge} {tag} {arrow} {msg}")

def log_video_tick(pos: int, target: int, step: int, delay: float):
    pct = min(100.0, (pos / max(1, target)) * 100)
    badge = make_badge("VIDEO-TICK", (168, 85, 247), (255, 255, 255), width=11)
    tag = f"{fg_rgb(*PURPLE_LIGHT)}[{pos:>4}/{target:<4}s ({pct:>5.1f}%)]"
    arrow = f"{fg_rgb(*PURPLE_NEON)}──>{RESET}"
    msg = f"{fg_rgb(*WHITE_BRIGHT)}Advancing +{step}s | Wait {delay:.1f}s{RESET}"
    print(f"   {badge} {tag} {arrow} {msg}")

def log_reward_code(quest_name: str, code: str):
    badge = make_badge("PROMO CODE", (250, 204, 21), (0, 0, 0), width=12)
    arrow = f"{fg_rgb(*YELLOW_GOLD)}──★{RESET}"
    msg = f"{fg_rgb(*WHITE_BRIGHT)}{quest_name}: {fg_rgb(*YELLOW_GOLD)}{BOLD}{code}{RESET}"
    print(f"   {badge} {arrow} {msg}")

def log_captcha_notice(quest_name: str):
    badge = make_badge("CAPTCHA", (245, 158, 11), (0, 0, 0), width=10)
    arrow = f"{fg_rgb(*YELLOW_GOLD)}──!{RESET}"
    msg = (
        f"{fg_rgb(*YELLOW_GOLD)}{BOLD}Discord Human Verification Required for '{quest_name}'{RESET}\n"
        f"   {fg_rgb(*GRAY_MUTED)}│  Notice: Discord issued an hCaptcha challenge for this reward redemption.\n"
        f"   {fg_rgb(*GRAY_MUTED)}│  Action: Please open Discord (User Settings -> Gift Inventory -> Quests)\n"
        f"   {fg_rgb(*GRAY_MUTED)}│          and click 'Claim Reward' manually in the app.{RESET}"
    )
    print(f"   {badge} {arrow} {msg}")

def log_relay_online(local_ip: str, port: int, quest_name: str, engine_name: str = "Chromium", **kwargs):
    badge = make_badge("HCAP RELAY", (168, 85, 247), (255, 255, 255), width=12)
    arrow = f"{fg_rgb(*CYAN_ELECTRIC)}──★{RESET}"
    network_link = f"http://{local_ip}:{port}/"
    local_link = f"http://127.0.0.1:{port}/"

    msg = (
        f"{fg_rgb(*CYAN_ELECTRIC)}{BOLD}Interactive Captcha Relay Online for '{quest_name}'{RESET}\n"
        f"   {fg_rgb(*GRAY_BORDER)}╭────────────────────────────────────────────────────────────────────────╮{RESET}\n"
        f"   {fg_rgb(*GRAY_BORDER)}│{RESET}  {fg_rgb(*GREEN_NEON)}{BOLD}UNIVERSAL BROWSER COMPATIBLE — Chrome, Firefox, Safari, Brave, Mobile{RESET}  {fg_rgb(*GRAY_BORDER)}│{RESET}\n"
        f"   {fg_rgb(*GRAY_BORDER)}│{RESET}  {fg_rgb(*GRAY_MUTED)}Engine Backend: {engine_name:<54}{RESET} {fg_rgb(*GRAY_BORDER)}│{RESET}\n"
        f"   {fg_rgb(*GRAY_BORDER)}├────────────────────────────────────────────────────────────────────────┤{RESET}\n"
        f"   {fg_rgb(*GRAY_BORDER)}│{RESET}  {fg_rgb(*YELLOW_GOLD)}{BOLD}Wi-Fi Link (Phone/Tablet/LAN):{RESET}{' ' * 38} {fg_rgb(*GRAY_BORDER)}│{RESET}\n"
        f"   {fg_rgb(*GRAY_BORDER)}│{RESET}  {fg_rgb(*CYAN_ELECTRIC)}{BOLD}{network_link:<68}{RESET} {fg_rgb(*GRAY_BORDER)}│{RESET}\n"
        f"   {fg_rgb(*GRAY_BORDER)}│{RESET}  {fg_rgb(*GRAY_MUTED)}Localhost link: {local_link:<53}{RESET} {fg_rgb(*GRAY_BORDER)}│{RESET}\n"
        f"   {fg_rgb(*GRAY_BORDER)}├────────────────────────────────────────────────────────────────────────┤{RESET}\n"
        f"   {fg_rgb(*GRAY_BORDER)}│{RESET}  {fg_rgb(*WHITE_BRIGHT)}• Open the link in ANY browser on your phone, tablet, or PC{' ' * 10}{RESET} {fg_rgb(*GRAY_BORDER)}│{RESET}\n"
        f"   {fg_rgb(*GRAY_BORDER)}│{RESET}  {fg_rgb(*PURPLE_LIGHT)}• Solve the puzzle tiles on the page to auto-redeem the reward.{' ' * 6}{RESET} {fg_rgb(*GRAY_BORDER)}│{RESET}\n"
        f"   {fg_rgb(*GRAY_BORDER)}╰────────────────────────────────────────────────────────────────────────╯{RESET}"
    )
    print(f"   {badge} {arrow} {msg}")

def render_quests_table(quests: List[Any], title_prefix: str = "CURRENTLY ACTIVE DISCORD QUESTS", width: Optional[int] = None) -> List[str]:
    if width is None:
        width = get_term_width()

    box_w = min(width - 4, 90)
    b_col = fg_rgb(*CYAN_MID)
    lines: List[str] = []

    top_border = f"{b_col}╭{'─' * (box_w - 2)}╮{RESET}"
    lines.append(center(top_border, width))

    title_text = f"{BOLD}{fg_rgb(*WHITE_BRIGHT)}{title_prefix} ({len(quests)}){RESET}"
    pad = (box_w - 2 - len(strip_ansi(title_text))) // 2
    r_pad = box_w - 2 - len(strip_ansi(title_text)) - pad
    lines.append(center(f"{b_col}│{RESET}{' ' * pad}{title_text}{' ' * r_pad}{b_col}│{RESET}", width))

    sep_border = f"{b_col}├{'─' * (box_w - 2)}┤{RESET}"
    lines.append(center(sep_border, width))

    hdr = f" {'#':<3} │ {'Quest Name':<28} │ {'Task Type':<16} │ {'Target':<6} │ {'Progress':<9} │ {'Status'}"
    h_pad = max(0, box_w - 2 - len(strip_ansi(hdr)))
    lines.append(center(f"{b_col}│{RESET}{fg_rgb(*CYAN_ELECTRIC)}{BOLD}{hdr}{RESET}{' ' * h_pad}{b_col}│{RESET}", width))

    sub_sep = f"{b_col}├{'─' * 5}┼{'─' * 30}┼{'─' * 18}┼{'─' * 8}┼{'─' * 11}┼{'─' * (box_w - 78)}┤{RESET}"
    lines.append(center(sub_sep, width))

    if not quests:
        no_q = "No matching quests found on this account."
        p = (box_w - 2 - len(no_q)) // 2
        lines.append(center(f"{b_col}│{RESET}{' ' * p}{fg_rgb(*GRAY_MUTED)}{no_q}{RESET}{' ' * (box_w - 2 - len(no_q) - p)}{b_col}│{RESET}", width))
    else:
        for idx, q in enumerate(quests, 1):
            if q.is_expired:
                status_badge = f"{bg_rgb(185, 28, 28)}{fg_rgb(255, 255, 255)}{BOLD} EXPIRED  {RESET}"
            elif q.claimed:
                status_badge = f"{bg_rgb(16, 185, 129)}{fg_rgb(0, 0, 0)}{BOLD} CLAIMED  {RESET}"
            elif q.completed:
                status_badge = f"{bg_rgb(52, 211, 153)}{fg_rgb(0, 0, 0)}{BOLD} FINISHED {RESET}"
            elif q.enrolled:
                status_badge = f"{bg_rgb(14, 165, 233)}{fg_rgb(0, 0, 0)}{BOLD} ENROLLED {RESET}"
            else:
                exp_label = q.expires_in_display
                status_badge = f"{bg_rgb(51, 65, 85)}{fg_rgb(255, 255, 255)} {exp_label:<8} {RESET}"

            prog_str = f"{q.current_progress_seconds}/{q.target_seconds}s"
            row = (
                f" {idx:<3} │ {q.config.quest_name[:26]:<28} │ "
                f"{q.primary_task_type[:14]:<16} │ {q.target_seconds:<6} │ "
                f"{prog_str:<9} │ {status_badge}"
            )
            r_pad = max(0, box_w - 2 - len(strip_ansi(row)))
            lines.append(center(f"{b_col}│{RESET}{row}{' ' * r_pad}{b_col}│{RESET}", width))

    bottom_border = f"{b_col}╰{'─' * (box_w - 2)}╯{RESET}"
    lines.append(center(bottom_border, width))
    return lines

def render_accounts_table(tokens: List[str], active_idx: int = -1, width: Optional[int] = None) -> List[str]:
    if width is None:
        width = get_term_width()

    box_w = min(width - 4, 84)
    b_col = fg_rgb(*PURPLE_NEON)
    lines: List[str] = []

    top_border = f"{b_col}╭{'─' * (box_w - 2)}╮{RESET}"
    lines.append(center(top_border, width))

    title_text = f"{BOLD}{fg_rgb(*WHITE_BRIGHT)}ACCOUNT MANAGER (LOADED TOKENS: {len(tokens)}){RESET}"
    pad = (box_w - 2 - len(strip_ansi(title_text))) // 2
    r_pad = box_w - 2 - len(strip_ansi(title_text)) - pad
    lines.append(center(f"{b_col}│{RESET}{' ' * pad}{title_text}{' ' * r_pad}{b_col}│{RESET}", width))

    sep_border = f"{b_col}├{'─' * (box_w - 2)}┤{RESET}"
    lines.append(center(sep_border, width))

    for idx, tok in enumerate(tokens):
        masked = tok[:12] + "..." + tok[-8:] if len(tok) > 20 else tok
        is_active = (idx == active_idx)
        badge = (
            f"{bg_rgb(16, 185, 129)}{fg_rgb(0, 0, 0)}{BOLD} [ACTIVE ACCOUNT] {RESET}"
            if is_active
            else f"{bg_rgb(51, 65, 85)}{fg_rgb(148, 163, 184)} [STANDBY]        {RESET}"
        )
        row = f"  <{idx + 1:02d}>  {fg_rgb(*WHITE_BRIGHT)}{masked:<32}{RESET}  {badge}"
        r_pad = max(0, box_w - 2 - len(strip_ansi(row)))
        lines.append(center(f"{b_col}│{RESET}{row}{' ' * r_pad}{b_col}│{RESET}", width))

    bottom_border = f"{b_col}╰{'─' * (box_w - 2)}╯{RESET}"
    lines.append(center(bottom_border, width))
    return lines
