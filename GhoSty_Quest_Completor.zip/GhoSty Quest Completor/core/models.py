from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

@dataclass
class GhostyReward:
    type: int
    name: str
    sku_id: str
    asset: Optional[str]
    code: Optional[str] = None

@dataclass
class GhostyTaskProgress:
    event_name: str
    value: int
    completed: bool

class GhostyQuestConfig:
    def __init__(self, data: dict):
        self.id: str = str(data.get("id", ""))
        self.config_version: int = data.get("config_version", 2)
        self.starts_at: Optional[str] = data.get("starts_at")
        self.expires_at: Optional[str] = data.get("expires_at")

        app = data.get("application", {})
        self.application_id: str = str(app.get("id", ""))
        self.application_name: str = app.get("name", "")

        msgs = data.get("messages", {})
        self.quest_name: str = msgs.get("quest_name", "Unknown Quest")
        self.game_title: str = msgs.get("game_title", self.application_name or "Unknown Game")
        self.game_publisher: str = msgs.get("game_publisher", "")

        rewards_data = data.get("rewards_config", {}).get("rewards", [])
        self.rewards: List[GhostyReward] = []
        for r in rewards_data:
            m = r.get("messages", {})
            self.rewards.append(
                GhostyReward(
                    type=r.get("type", 0),
                    name=m.get("name", "Reward"),
                    sku_id=str(r.get("sku_id", "")),
                    asset=r.get("asset"),
                )
            )

        task_cfg = data.get("task_config_v2", {})
        self.tasks: Dict[str, Any] = task_cfg.get("tasks", {})

    def ghosty_get_primary_task_type(self) -> str:
        if not self.tasks:
            return "UNKNOWN"
        for preferred in ("PLAY_ON_DESKTOP", "STREAM_ON_DESKTOP", "PLAY_ON_XBOX", "PLAY_ON_PLAYSTATION", "WATCH_VIDEO"):
            if preferred in self.tasks:
                return preferred
        return next(iter(self.tasks.keys()))

    def ghosty_get_target(self, task_type: str) -> int:
        task_info = self.tasks.get(task_type, {})
        return int(task_info.get("target", 900))

    def ghosty_get_application_ids(self, task_type: str) -> List[str]:
        task_info = self.tasks.get(task_type, {})
        return [str(a["id"]) for a in task_info.get("applications", [])]

class GhostyQuestUserStatus:
    def __init__(self, data: dict):
        self.user_id: str = str(data.get("user_id", ""))
        self.quest_id: str = str(data.get("quest_id", ""))
        self.enrolled_at: Optional[str] = data.get("enrolled_at")
        self.completed_at: Optional[str] = data.get("completed_at")
        self.claimed_at: Optional[str] = data.get("claimed_at")

        self.progress: Dict[str, GhostyTaskProgress] = {}
        for k, v in data.get("progress", {}).items():
            self.progress[k] = GhostyTaskProgress(
                event_name=v.get("event_name", k),
                value=int(v.get("value", 0)),
                completed=v.get("completed_at") is not None,
            )

    @property
    def is_enrolled(self) -> bool:
        return self.enrolled_at is not None

    @property
    def is_completed(self) -> bool:
        return self.completed_at is not None

    @property
    def is_claimed(self) -> bool:
        return self.claimed_at is not None

    def ghosty_get_progress_value(self, task_type: str) -> int:
        p = self.progress.get(task_type)
        if p and p.value > 0:
            return p.value
        for task_progress in self.progress.values():
            if task_progress.value > 0:
                return task_progress.value
        return p.value if p else 0

class GhostyQuest:
    def __init__(self, data: dict):
        self.raw_data: dict = data
        self.id: str = str(data.get("id", ""))
        config_data = data.get("config") if (isinstance(data.get("config"), dict)) else data
        self.config: GhostyQuestConfig = GhostyQuestConfig(config_data)
        self.preview: bool = bool(data.get("preview", False))
        self.traffic_metadata_sealed: Optional[str] = data.get("traffic_metadata_sealed")
        self.provenance_metadata_sealed: Optional[str] = (
            data.get("provenance_metadata_sealed") or data.get("metadata_sealed")
        )
        self.metadata_sealed: Optional[str] = self.provenance_metadata_sealed

        status_raw = data.get("user_status")
        self.user_status: Optional[GhostyQuestUserStatus] = (
            GhostyQuestUserStatus(status_raw) if status_raw else None
        )

    @property
    def enrolled(self) -> bool:
        return self.user_status is not None and self.user_status.is_enrolled

    @property
    def completed(self) -> bool:
        return self.user_status is not None and self.user_status.is_completed

    @property
    def claimed(self) -> bool:
        return self.user_status is not None and self.user_status.is_claimed

    @property
    def primary_task_type(self) -> str:
        return self.config.ghosty_get_primary_task_type()

    @property
    def target_seconds(self) -> int:
        return self.config.ghosty_get_target(self.primary_task_type)

    @property
    def current_progress_seconds(self) -> int:
        if not self.user_status:
            return 0
        return self.user_status.ghosty_get_progress_value(self.primary_task_type)

    @property
    def is_expired(self) -> bool:
        if not self.config.expires_at:
            return False
        try:
            exp_dt = datetime.fromisoformat(self.config.expires_at)
            return datetime.now(timezone.utc) > exp_dt
        except Exception:
            return False

    @property
    def expires_in_display(self) -> str:
        if not self.config.expires_at:
            return "Active"
        try:
            exp_dt = datetime.fromisoformat(self.config.expires_at)
            diff = exp_dt - datetime.now(timezone.utc)
            if diff.total_seconds() <= 0:
                return "EXPIRED"
            days = diff.days
            hours = diff.seconds // 3600
            if days > 0:
                return f"Ends in {days}d"
            return f"Ends in {hours}h"
        except Exception:
            return "Active"
