from __future__ import annotations

import json
import os
import sys
from typing import List, Optional

try:
    import colorama
    from colorama import Fore, Style
    colorama.init(autoreset=True)
    HAVE_COLORAMA = True
except ImportError:
    HAVE_COLORAMA = False

    class _DummyColor:
        def __getattr__(self, _):
            return ""

    Fore = _DummyColor()
    Style = _DummyColor()

class GhostyConsole:

    @staticmethod
    def ghosty_clear() -> None:
        if "TERMUX_VERSION" in os.environ or os.environ.get("TERM"):
            os.system("clear")
        elif os.name == "nt":
            os.system("cls")
        else:
            os.system("clear")

    @staticmethod
    def ghosty_banner() -> None:
        text = f"""
{Fore.LIGHTMAGENTA_EX}{Style.BRIGHT}
   ██████╗ ██╗  ██╗ ██████╗ ███████╗████████╗██╗   ██╗
  ██╔════╝ ██║  ██║██╔═══██╗██╔════╝╚══██╔══╝╚██╗ ██╔╝
  ██║  ███╗███████║██║   ██║███████╗   ██║    ╚████╔╝
  ██║   ██║██╔══██║██║   ██║╚════██║   ██║     ╚██╔╝
  ╚██████╔╝██║  ██║╚██████╔╝███████║   ██║      ██║
   ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚══════╝   ╚═╝      ╚═╝
{Fore.CYAN}            GHOSTY QUEST COMPLETOR SUITE
{Fore.LIGHTBLACK_EX}   [discord.py-self Gateway Sync] + [Chromium TLS / JA4 Impersonation]
{Fore.LIGHTBLACK_EX}   Compatible: Windows | Linux | macOS | Android Termux | Cloud
"""
        print(text)

    @staticmethod
    def ghosty_info(msg: str) -> None:
        print(f"{Fore.CYAN}[*] {msg}{Style.RESET_ALL}")

    @staticmethod
    def ghosty_success(msg: str) -> None:
        print(f"{Fore.GREEN}{Style.BRIGHT}[+] {msg}{Style.RESET_ALL}")

    @staticmethod
    def ghosty_warn(msg: str) -> None:
        print(f"{Fore.YELLOW}[!] {msg}{Style.RESET_ALL}")

    @staticmethod
    def ghosty_error(msg: str) -> None:
        print(f"{Fore.RED}[x] {msg}{Style.RESET_ALL}")

    @staticmethod
    def ghosty_progress(msg: str) -> None:
        print(f"{Fore.BLUE}[~] {msg}{Style.RESET_ALL}")

    @staticmethod
    def ghosty_accent(msg: str) -> None:
        print(f"{Fore.MAGENTA}[>] {msg}{Style.RESET_ALL}")

    @staticmethod
    def ghosty_highlight(msg: str) -> None:
        print(f"{Fore.LIGHTYELLOW_EX}{Style.BRIGHT}[★] {msg}{Style.RESET_ALL}")

class GhostyTokenManager:

    def __init__(self, filename: str = "tokens.txt"):
        self.filename = filename

    def ghosty_load_tokens(self) -> List[str]:
        if not os.path.exists(self.filename):
            with open(self.filename, "w", encoding="utf-8") as f:
                f.write("# Place your Discord account tokens here (one per line)\n")
            return []

        tokens: List[str] = []
        with open(self.filename, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    tokens.append(line)
        return tokens

    def ghosty_save_token(self, token: str) -> None:
        token = token.strip()
        if not token:
            return
        with open(self.filename, "a", encoding="utf-8") as f:
            f.write(f"\n{token}")

class GhostyConfig:

    def __init__(
        self,
        captcha_relay: bool = True,
        relay_host: str = "0.0.0.0",
        relay_port: int = 8787,
        auto_claim: bool = True,
        auto_open_browser: bool = True,
        browser_path: Optional[str] = None,
    ):
        self.captcha_relay = captcha_relay
        self.relay_host = relay_host
        self.relay_port = relay_port
        self.auto_claim = auto_claim
        self.auto_open_browser = auto_open_browser
        self.browser_path = browser_path

class GhostyConfigManager:

    def __init__(self, filename: str = "config.json"):
        self.filename = filename

    def ghosty_load_config(self) -> GhostyConfig:
        if not os.path.exists(self.filename):
            cfg = GhostyConfig()
            self.ghosty_save_config(cfg)
            return cfg

        try:
            with open(self.filename, "r", encoding="utf-8") as f:
                data = json.load(f)
            return GhostyConfig(
                captcha_relay=bool(data.get("captcha_relay", True)),
                relay_host=str(data.get("relay_host", "0.0.0.0")),
                relay_port=int(data.get("relay_port", 8787)),
                auto_claim=bool(data.get("auto_claim", True)),
                auto_open_browser=bool(data.get("auto_open_browser", True)),
                browser_path=data.get("browser_path"),
            )
        except Exception:
            return GhostyConfig()

    def ghosty_save_config(self, cfg: GhostyConfig) -> None:
        data = {
            "captcha_relay": cfg.captcha_relay,
            "relay_host": cfg.relay_host,
            "relay_port": cfg.relay_port,
            "auto_claim": cfg.auto_claim,
            "auto_open_browser": cfg.auto_open_browser,
            "browser_path": cfg.browser_path,
        }
        with open(self.filename, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
