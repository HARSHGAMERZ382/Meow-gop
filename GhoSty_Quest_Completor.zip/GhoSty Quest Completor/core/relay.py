from __future__ import annotations

import asyncio
import base64
import json
import os
import random
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, Optional, Tuple

try:
    import websocket
    HAVE_WEBSOCKET = True
except ImportError:
    HAVE_WEBSOCKET = False

from . import ui

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
)

BOOT_EXPR = """
(() => {{
  if (window.__ghcBoot && document.getElementById('ghc')) return 'ok';
  window.__ghcBoot = 1;
  window.__ghcToken = null;
  let host = document.getElementById('ghc');
  const rq = {rqdata};
  if (!host) {{
    host = document.createElement('div');
    host.id = 'ghc';
    host.style.cssText = 'position:fixed;left:20px;top:90px;z-index:2147483647';
    if (rq) host.setAttribute('data-rqdata', rq);
    host.setAttribute('data-sitekey', {sitekey});
    document.body.appendChild(host);
  }} else {{
    if (rq) host.setAttribute('data-rqdata', rq);
    host.setAttribute('data-sitekey', {sitekey});
  }}

  window.__ghcReady = () => {{
    if (!window.hcaptcha || !window.hcaptcha.render) return setTimeout(window.__ghcReady, 100);
    const opts = {{
      sitekey: {sitekey},
      callback: function(token) {{ window.__ghcToken = token; }},
      "error-callback": function(e) {{ console.error('ghc err', e); }},
      "expired-callback": function() {{ console.error('ghc expired'); window.__ghcToken = null; }}
    }};
    if (rq) {{
      opts.rqdata = rq;
    }}
    try {{
      window.__ghcId = hcaptcha.render('ghc', opts);
      if (rq && window.hcaptcha && window.hcaptcha.setData) {{
        try {{ window.hcaptcha.setData(window.__ghcId, {{ rqdata: rq }}); }} catch(e) {{}}
      }}
    }} catch (e) {{
      console.error('render failed', e);
    }}
  }};

  if (window.hcaptcha && window.hcaptcha.render) {{
      window.__ghcReady();
  }} else {{
      const s = document.createElement('script');
      s.src = 'https://js.hcaptcha.com/1/api.js?onload=__ghcReady&render=explicit';
      document.head.appendChild(s);
  }}
  return 'ok';
}})()
"""

RECT_EXPR = """(() => {
  const frames = Array.from(document.querySelectorAll('iframe'));
  const ch = frames.find(f => (f.title === 'hCaptcha challenge' || (f.src && f.src.includes('frame=challenge'))) && f.getBoundingClientRect().width > 100 && f.getBoundingClientRect().y > -500);
  if (ch) {
    const r = ch.getBoundingClientRect();
    if (r.width > 100 && r.height > 100) {
      return { x: r.x, y: r.y, w: r.width, h: r.height };
    }
  }
  const f = document.querySelector('#ghc iframe') || frames.find(f => f.title && f.title.includes('checkbox'));
  if (!f) return null;
  const r = f.getBoundingClientRect();
  if (!r.width || !r.height) return null;
  return { x: r.x, y: r.y, w: r.width, h: r.height };
})()"""

TOKEN_EXPR = (
    "(window.__ghcToken || "
    "(document.querySelector('textarea[name=\"h-captcha-response\"]') || {}).value || "
    "(document.querySelector('textarea[name=\"g-recaptcha-response\"]') || {}).value || '')"
)

PAGE_HTML = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>GhoSty Captcha Relay</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
  <meta name="theme-color" content="#000000">
  <style>
    @font-face {
      font-family: 'Bitcount Prop Single Light';
      src: url('/assets/BitcountPropSingle-Light.ttf') format('truetype'),
           url('BitcountPropSingle-Light.ttf') format('truetype');
      font-weight: 300 400;
      font-style: normal;
      font-display: swap;
    }

    *, *::before, *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    :root {
      --bg-black: #000000;
      --card-bg: #09090B;
      --card-border: #27272A;
      --border-subtle: #18181B;
      --text-white: #FFFFFF;
      --text-silver: #A1A1AA;
      --text-muted: #71717A;
      --text-dark: #3F3F46;
      --wireframe-line: rgba(255, 255, 255, 0.22);
    }
    html, body {
      width: 100%;
      min-height: 100vh;
      background-color: var(--bg-black);
      color: var(--text-white);
      font-family: 'Bitcount Prop Single Light', ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      overflow-x: hidden;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }
    .main-layout {
      position: relative;
      z-index: 10;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: max(16px, env(safe-area-inset-top)) 16px max(24px, env(safe-area-inset-bottom));
      width: 100%;
    }
    .panel-card {
      width: 100%;
      max-width: 500px;
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 4px;
      padding: 20px;
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    /* Technical architectural corner marks */
    .corner-mark {
      position: absolute;
      width: 7px;
      height: 7px;
      pointer-events: none;
    }
    .corner-tl { top: -1px; left: -1px; border-top: 2px solid #FFFFFF; border-left: 2px solid #FFFFFF; }
    .corner-tr { top: -1px; right: -1px; border-top: 2px solid #FFFFFF; border-right: 2px solid #FFFFFF; }
    .corner-bl { bottom: -1px; left: -1px; border-bottom: 2px solid #FFFFFF; border-left: 2px solid #FFFFFF; }
    .corner-br { bottom: -1px; right: -1px; border-bottom: 2px solid #FFFFFF; border-right: 2px solid #FFFFFF; }

    .header-top {
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
      padding-bottom: 12px;
      border-bottom: 1px solid var(--border-subtle);
    }
    .brand-group {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    /* Wireframe isometric cube glyph */
    .brand-icon-wireframe {
      width: 16px;
      height: 16px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    .brand-icon-wireframe svg {
      width: 16px;
      height: 16px;
      stroke: #FFFFFF;
      stroke-width: 1.4;
      fill: none;
    }
    .brand-title {
      font-size: 14px;
      font-weight: 700;
      letter-spacing: 1.5px;
      color: #FFFFFF;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .brand-tag {
      font-size: 11px;
      font-weight: 400;
      color: var(--text-silver);
      border: 1px solid var(--text-dark);
      padding: 1px 6px;
      border-radius: 2px;
      letter-spacing: 1px;
    }
    .status-badge {
      font-size: 11px;
      font-weight: 500;
      padding: 4px 8px;
      border-radius: 2px;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: #000000;
      color: var(--text-muted);
      border: 1px solid var(--border-subtle);
      letter-spacing: 0.5px;
    }
    .status-badge .indicator-box {
      width: 6px;
      height: 6px;
      background: var(--text-dark);
    }
    .status-badge.live {
      color: #FFFFFF;
      border-color: #525252;
    }
    .status-badge.live .indicator-box {
      background: #FFFFFF;
      animation: blinkCursor 1s steps(1) infinite;
    }
    .status-badge.solved {
      color: #000000;
      background: #FFFFFF;
      border-color: #FFFFFF;
      font-weight: 700;
    }
    .status-badge.solved .indicator-box {
      background: #000000;
    }
    @keyframes blinkCursor {
      0%, 49% { opacity: 1; }
      50%, 100% { opacity: 0; }
    }
    #wrap {
      width: 100%;
      min-height: 240px;
      background: #000000;
      border: 1px solid var(--card-border);
      border-radius: 2px;
      position: relative;
      overflow: hidden;
      display: flex;
      justify-content: center;
      align-items: center;
      touch-action: none;
      -webkit-touch-callout: none;
      -webkit-user-select: none;
      user-select: none;
    }
    .wrap-crosshair {
      position: absolute;
      width: 9px;
      height: 9px;
      pointer-events: none;
      z-index: 2;
    }
    .wc-tl { top: 4px; left: 4px; border-top: 1px solid var(--text-muted); border-left: 1px solid var(--text-muted); }
    .wc-tr { top: 4px; right: 4px; border-top: 1px solid var(--text-muted); border-right: 1px solid var(--text-muted); }
    .wc-bl { bottom: 4px; left: 4px; border-bottom: 1px solid var(--text-muted); border-left: 1px solid var(--text-muted); }
    .wc-br { bottom: 4px; right: 4px; border-bottom: 1px solid var(--text-muted); border-right: 1px solid var(--text-muted); }

    #f {
      display: block;
      cursor: crosshair;
      user-select: none;
      -webkit-user-drag: none;
      touch-action: none;
      max-width: 100%;
      height: auto;
    }
    .placeholder-state {
      position: absolute;
      inset: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 14px;
      color: var(--text-muted);
      font-size: 11px;
      letter-spacing: 1.2px;
    }
    /* Technical wireframe reticle spinner */
    .wireframe-spinner {
      width: 36px;
      height: 36px;
      position: relative;
    }
    .wireframe-spinner::before {
      content: "";
      position: absolute;
      inset: 0;
      border: 1px solid var(--text-dark);
      border-radius: 2px;
    }
    .wireframe-spinner::after {
      content: "";
      position: absolute;
      inset: 6px;
      border: 1px solid #FFFFFF;
      border-radius: 50%;
      border-right-color: transparent;
      animation: spinReticle 1.2s linear infinite;
    }
    @keyframes spinReticle {
      100% { transform: rotate(360deg); }
    }
    /* Technical wireframe crosshair tap target */
    .tap-indicator {
      position: absolute;
      width: 22px;
      height: 22px;
      border: 1px solid #FFFFFF;
      transform: translate(-50%, -50%) scale(0.6);
      pointer-events: none;
      z-index: 100;
      animation: tapWireframe 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }
    .tap-indicator::before, .tap-indicator::after {
      content: "";
      position: absolute;
      background: #FFFFFF;
    }
    .tap-indicator::before {
      top: 50%; left: -4px; right: -4px; height: 1px; transform: translateY(-50%);
    }
    .tap-indicator::after {
      left: 50%; top: -4px; bottom: -4px; width: 1px; transform: translateX(-50%);
    }
    @keyframes tapWireframe {
      0% { transform: translate(-50%, -50%) scale(0.6); opacity: 1; }
      100% { transform: translate(-50%, -50%) scale(1.3); opacity: 0; }
    }
    #info-bar {
      margin-top: 14px;
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #000000;
      border: 1px solid var(--card-border);
      border-radius: 2px;
      padding: 8px 12px;
      font-size: 11px;
      color: var(--text-silver);
    }
    .endpoint-pill {
      display: flex;
      align-items: center;
      gap: 6px;
      letter-spacing: 0.5px;
    }
    .endpoint-pill strong {
      color: #FFFFFF;
      font-weight: 600;
    }
    #copy-btn {
      background: #111111;
      color: #FFFFFF;
      border: 1px solid var(--text-dark);
      border-radius: 2px;
      padding: 6px 14px;
      min-height: 36px;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      font-family: inherit;
      letter-spacing: 0.8px;
      transition: background 0.15s, color 0.15s, border-color 0.15s;
    }
    #copy-btn:hover, #copy-btn:active {
      background: #FFFFFF;
      color: #000000;
      border-color: #FFFFFF;
    }
    #hint {
      margin-top: 12px;
      font-size: 11px;
      color: var(--text-muted);
      text-align: center;
      line-height: 1.6;
      letter-spacing: 0.4px;
    }
    #hint strong {
      color: var(--text-silver);
      font-weight: 600;
    }
    /* Technical Success Confirmation Panel */
    #success-panel {
      width: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      padding: 8px 0;
      animation: panelIn 0.25s ease-out;
    }
    @keyframes panelIn {
      from { opacity: 0; transform: translateY(6px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .success-box {
      width: 44px;
      height: 44px;
      border: 1px solid #FFFFFF;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 16px;
      background: #000000;
    }
    .success-box svg {
      width: 22px;
      height: 22px;
      stroke: #FFFFFF;
      stroke-width: 2;
      fill: none;
      stroke-linecap: square;
      stroke-linejoin: miter;
    }
    #claimed-heading {
      font-size: 15px;
      font-weight: 700;
      letter-spacing: 2px;
      color: #FFFFFF;
      margin-bottom: 6px;
    }
    #claimed-quest {
      font-size: 12px;
      color: var(--text-silver);
      margin-bottom: 14px;
      letter-spacing: 1px;
    }
    .claimed-badge {
      display: inline-block;
      padding: 4px 10px;
      border: 1px solid var(--text-dark);
      background: #000000;
      color: #FFFFFF;
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 1.5px;
      margin-bottom: 18px;
      border-radius: 2px;
    }
    #code-card {
      width: 100%;
      background: #000000;
      border: 1px solid #525252;
      border-radius: 2px;
      padding: 16px;
      margin-bottom: 18px;
      text-align: center;
    }
    .code-label {
      font-size: 10px;
      letter-spacing: 1.5px;
      color: var(--text-muted);
      margin-bottom: 8px;
      font-weight: 600;
    }
    #code-val {
      font-size: 17px;
      font-weight: 700;
      letter-spacing: 2px;
      color: #FFFFFF;
      margin-bottom: 12px;
      word-break: break-all;
      user-select: all;
      cursor: pointer;
      transition: opacity 0.15s;
    }
    #code-val:hover {
      opacity: 0.85;
    }
    #copy-code-btn {
      background: #FFFFFF;
      color: #000000;
      border: 1px solid #FFFFFF;
      border-radius: 2px;
      padding: 8px 18px;
      min-height: 40px;
      font-size: 11px;
      font-weight: 700;
      cursor: pointer;
      font-family: inherit;
      letter-spacing: 1px;
      transition: background 0.15s, color 0.15s;
    }
    #copy-code-btn:hover, #copy-code-btn:active {
      background: #000000;
      color: #FFFFFF;
    }
    .claimed-footer {
      font-size: 10px;
      color: var(--text-muted);
      line-height: 1.6;
      letter-spacing: 0.5px;
    }
    @media (max-width: 520px) {
      .panel-card {
        padding: 16px 12px;
      }
      .brand-title {
        font-size: 12px;
      }
      #copy-btn {
        padding: 8px 14px;
        min-height: 44px; /* Touch target accessibility rule */
      }
      #copy-code-btn {
        min-height: 44px;
        width: 100%;
      }
    }
  </style>
</head>
<body>
  <div class="main-layout">
    <div class="panel-card">
      <div class="corner-mark corner-tl"></div>
      <div class="corner-mark corner-tr"></div>
      <div class="corner-mark corner-bl"></div>
      <div class="corner-mark corner-br"></div>

      <div class="header-top">
        <div class="brand-group">
          <div class="brand-icon-wireframe">
            <svg viewBox="0 0 24 24">
              <polygon points="12 2 22 8.5 12 15 2 8.5"></polygon>
              <polyline points="2 8.5 2 15.5 12 22 22 15.5 22 8.5"></polyline>
              <line x1="12" y1="15" x2="12" y2="22"></line>
            </svg>
          </div>
          <div class="brand-title">
            GHOSTY <span class="brand-tag">GhoSty Relay Bridge</span>
          </div>
        </div>
        <div id="st" class="status-badge">
          <span class="indicator-box"></span>
          <span id="st-text">INITIALIZING...</span>
        </div>
      </div>

      <div id="wrap">
        <div class="wrap-crosshair wc-tl"></div>
        <div class="wrap-crosshair wc-tr"></div>
        <div class="wrap-crosshair wc-bl"></div>
        <div class="wrap-crosshair wc-br"></div>

        <div id="placeholder" class="placeholder-state">
          <div class="wireframe-spinner"></div>
          <div>LOADING VERIFICATION PUZZLE...</div>
        </div>
        <img id="f" alt="" style="display:none;">
        <div id="direct-hcaptcha" style="display:none; z-index: 10; margin: 16px auto; min-height: 80px; align-items: center; justify-content: center;"></div>
      </div>

      <div id="info-bar">
        <div class="endpoint-pill">
          ENDPOINT: <strong id="cur-url">8787</strong>
        </div>
        <button id="copy-btn" onclick="copyLink()">COPY URL</button>
      </div>

      <div id="hint">
        Tap or click puzzle images directly to solve.<br>
        Verified token submits automatically to <strong>GhoSty Completor</strong>.
      </div>

      <!-- Technical Success Panel -->
      <div id="success-panel" style="display:none;">
        <div class="success-box">
          <svg viewBox="0 0 24 24">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
        </div>
        <h2 id="claimed-heading">QUEST REWARD CLAIMED</h2>
        <div id="claimed-quest">Discord Quest</div>
        <div class="claimed-badge">CONFIRMED ON DISCORD SERVER</div>
        <div id="code-card" style="display:none;">
          <div class="code-label">REDEEMABLE PROMO CODE</div>
          <div id="code-val" onclick="copyPromoCode()" title="Click to copy code"></div>
          <button id="copy-code-btn" onclick="copyPromoCode()">COPY CODE</button>
        </div>
        <div class="claimed-footer">
          Reward is added to your Discord account inventory.<br>
          You can safely close this browser window.
        </div>
      </div>
    </div>
  </div>

  <script>
    // -------------------------------------------------------------
    // Relay Mirror Frame & Input Event Pipeline
    // -------------------------------------------------------------
    const f = document.getElementById('f');
    const wrap = document.getElementById('wrap');
    const placeholder = document.getElementById('placeholder');
    const st = document.getElementById('st');
    const stText = document.getElementById('st-text');
    const curUrl = document.getElementById('cur-url');
    curUrl.textContent = window.location.host;

    let lastBlobUrl = null;

    function pull() {
      fetch('/frame.jpg?' + Date.now())
        .then(r => {
          if (r.status !== 200) throw 0;
          return r.blob();
        })
        .then(b => {
          const newUrl = URL.createObjectURL(b);
          f.src = newUrl;
          if (f.style.display === 'none') {
            f.style.display = 'block';
            if (placeholder) placeholder.style.display = 'none';
          }
          if (lastBlobUrl) {
            URL.revokeObjectURL(lastBlobUrl);
          }
          lastBlobUrl = newUrl;
        })
        .catch(() => {});
    }
    setInterval(pull, 200);
    pull();

    function pos(e) {
      const r = f.getBoundingClientRect();
      const scaleX = (f.naturalWidth && r.width) ? (f.naturalWidth / r.width) : 1;
      const scaleY = (f.naturalHeight && r.height) ? (f.naturalHeight / r.height) : 1;
      return { x: (e.clientX - r.left) * scaleX, y: (e.clientY - r.top) * scaleY };
    }

    function createTapMarker(clientX, clientY) {
      const r = wrap.getBoundingClientRect();
      const dot = document.createElement('div');
      dot.className = 'tap-indicator';
      dot.style.left = (clientX - r.left) + 'px';
      dot.style.top = (clientY - r.top) + 'px';
      wrap.appendChild(dot);
      setTimeout(() => dot.remove(), 300);
    }

    function send(t, x, y) {
      fetch('/input', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ t: t, x: x, y: y })
      }).catch(() => {});
    }

    let lastMove = 0;
    f.addEventListener('mousemove', e => {
      const n = Date.now();
      if (n - lastMove < 35) return;
      lastMove = n;
      const p = pos(e);
      send('move', p.x, p.y);
    });
    f.addEventListener('mousedown', e => {
      e.preventDefault();
      createTapMarker(e.clientX, e.clientY);
      const p = pos(e);
      send('press', p.x, p.y);
    });
    window.addEventListener('mouseup', e => {
      const p = pos(e);
      send('release', p.x, p.y);
    });
    f.addEventListener('contextmenu', e => e.preventDefault());

    f.addEventListener('touchstart', e => {
      e.preventDefault();
      if (!e.touches.length) return;
      const t = e.touches[0];
      createTapMarker(t.clientX, t.clientY);
      const p = pos(t);
      send('press', p.x, p.y);
    }, { passive: false });

    f.addEventListener('touchmove', e => {
      e.preventDefault();
      if (!e.touches.length) return;
      const t = e.touches[0];
      const p = pos(t);
      send('move', p.x, p.y);
    }, { passive: false });

    f.addEventListener('touchend', e => {
      e.preventDefault();
      if (!e.changedTouches.length) return;
      const t = e.changedTouches[0];
      const p = pos(t);
      send('release', p.x, p.y);
    }, { passive: false });

    let directCaptchaInitialized = false;

    function initDirectCaptcha(sitekey, rqdata) {
      if (directCaptchaInitialized) return;
      directCaptchaInitialized = true;

      const directEl = document.getElementById('direct-hcaptcha');
      if (placeholder) placeholder.style.display = 'none';
      if (f) f.style.display = 'none';
      if (directEl) directEl.style.display = 'flex';

      window.__onDirectReady = function() {
        if (!window.hcaptcha || !window.hcaptcha.render) {
          setTimeout(window.__onDirectReady, 100);
          return;
        }
        try {
          const opts = {
            sitekey: sitekey,
            theme: 'dark',
            callback: function(token) {
              stText.textContent = 'VERIFIED // CLAIMING...';
              st.className = 'status-badge solved';
              fetch('/solve', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token: token })
              }).catch(function() {});
            },
            'expired-callback': function() {
              stText.textContent = 'CHALLENGE EXPIRED';
              st.className = 'status-badge';
            },
            'error-callback': function(err) {
              console.error('hCaptcha error', err);
            }
          };
          if (rqdata) {
            opts.rqdata = rqdata;
          }
          const widgetId = hcaptcha.render('direct-hcaptcha', opts);
          if (rqdata && window.hcaptcha.setData) {
            try { window.hcaptcha.setData(widgetId, { rqdata: rqdata }); } catch(e) {}
          }
          stText.textContent = 'ACTIVE VERIFICATION';
          st.className = 'status-badge live';
        } catch (e) {
          console.error('Direct render error', e);
        }
      };

      if (window.hcaptcha && window.hcaptcha.render) {
        window.__onDirectReady();
      } else {
        const s = document.createElement('script');
        s.src = 'https://js.hcaptcha.com/1/api.js?onload=__onDirectReady&render=explicit';
        s.async = true;
        s.defer = true;
        document.head.appendChild(s);
      }
    }

    let hasClaimed = false;
    setInterval(() => {
      fetch('/status')
        .then(r => r.json())
        .then(s => {
          if (s.mode === 'direct' && s.sitekey) {
            initDirectCaptcha(s.sitekey, s.rqdata);
          }
          if (s.claimed) {
            if (!hasClaimed) {
              hasClaimed = true;
              showClaimedScreen(s);
            }
          } else if (s.solved) {
            stText.textContent = 'VERIFIED // CLAIMING...';
            st.className = 'status-badge solved';
          } else if (s.mode === 'direct' || s.rect) {
            stText.textContent = 'ACTIVE VERIFICATION';
            st.className = 'status-badge live';
          } else {
            stText.textContent = 'WAITING FOR WIDGET';
            st.className = 'status-badge';
          }
        })
        .catch(() => {});
    }, 250);

    function showClaimedScreen(s) {
      document.getElementById('wrap').style.display = 'none';
      document.getElementById('hint').style.display = 'none';
      document.getElementById('info-bar').style.display = 'none';
      stText.textContent = 'CLAIMED';
      st.className = 'status-badge solved';

      const panel = document.getElementById('success-panel');
      panel.style.display = 'flex';

      if (s.quest_name) {
        document.getElementById('claimed-quest').textContent = s.quest_name;
      }
      if (s.promo_code) {
        document.getElementById('code-card').style.display = 'block';
        document.getElementById('code-val').textContent = s.promo_code;
      }
    }

    function copyTextToClipboard(text, btnElement, successText, resetText) {
      if (!text) return;

      function onCopied() {
        if (btnElement) {
          const original = btnElement.textContent;
          btnElement.textContent = successText;
          btnElement.style.background = '#000000';
          btnElement.style.color = '#FFFFFF';
          btnElement.style.borderColor = '#FFFFFF';
          setTimeout(() => {
            btnElement.textContent = resetText || original;
            btnElement.style.background = '';
            btnElement.style.color = '';
            btnElement.style.borderColor = '';
          }, 1800);
        }
      }

      function execCommandFallback() {
        try {
          const ta = document.createElement('textarea');
          ta.value = text;
          ta.style.position = 'fixed';
          ta.style.top = '0';
          ta.style.left = '-9999px';
          ta.style.opacity = '0';
          ta.setAttribute('readonly', '');
          document.body.appendChild(ta);
          ta.focus();
          ta.select();
          ta.setSelectionRange(0, 99999);
          const ok = document.execCommand('copy');
          document.body.removeChild(ta);
          if (ok) {
            onCopied();
            return true;
          }
        } catch (e) {}
        return false;
      }

      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(onCopied).catch(() => {
          if (!execCommandFallback()) {
            window.prompt('Copy to clipboard:', text);
            onCopied();
          }
        });
      } else {
        if (!execCommandFallback()) {
          window.prompt('Copy to clipboard:', text);
          onCopied();
        }
      }
    }

    function copyLink() {
      const btn = document.getElementById('copy-btn');
      copyTextToClipboard(window.location.href, btn, 'COPIED!', 'COPY URL');
    }

    function copyPromoCode() {
      const codeEl = document.getElementById('code-val');
      const code = (codeEl ? codeEl.textContent : '').trim();
      const btn = document.getElementById('copy-code-btn');
      copyTextToClipboard(code, btn, 'COPIED!', 'COPY CODE');
    }
  </script>
</body>
</html>
"""

def get_local_ip() -> str:

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        pass

    try:
        host_name = socket.gethostname()
        ip = socket.gethostbyname(host_name)
        if ip and not ip.startswith("127."):
            return ip
    except Exception:
        pass

    return "127.0.0.1"

def find_browser(override_path: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:

    if override_path:
        override_clean = override_path.strip().strip('"').strip("'")
        if os.path.isfile(override_clean):
            return override_clean, "Custom Binary"

        kw = override_clean.lower()
        which_path = shutil.which(kw)
        if which_path and "WindowsApps" not in which_path and os.path.isfile(which_path):
            return which_path, f"{kw.capitalize()} (PATH)"

    if "ANDROID_ROOT" in os.environ or "TERMUX_VERSION" in os.environ or "com.termux" in os.environ.get("PREFIX", ""):
        return None, None

    if os.name == "nt":
        prog = os.environ.get("PROGRAMFILES", r"C:\Program Files")
        prog86 = os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")
        local = os.environ.get("LOCALAPPDATA", "")

        chrome_candidates = [
            os.path.join(prog, "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(prog86, "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(local, "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(local, "Google", "Chrome SxS", "Application", "chrome.exe"),
        ]
        for p in chrome_candidates:
            if os.path.isfile(p):
                return p, "Google Chrome"

        brave_candidates = [
            os.path.join(prog, "BraveSoftware", "Brave-Browser", "Application", "brave.exe"),
            os.path.join(local, "BraveSoftware", "Brave-Browser", "Application", "brave.exe"),
            os.path.join(prog86, "BraveSoftware", "Brave-Browser", "Application", "brave.exe"),
        ]
        for p in brave_candidates:
            if os.path.isfile(p):
                return p, "Brave Browser"

        chromium_candidates = [
            os.path.join(local, "Chromium", "Application", "chrome.exe"),
            os.path.join(prog, "Chromium", "Application", "chrome.exe"),
            os.path.join(prog86, "Chromium", "Application", "chrome.exe"),
        ]
        for p in chromium_candidates:
            if os.path.isfile(p):
                return p, "Chromium"

        opera_candidates = [
            os.path.join(local, "Programs", "Opera", "opera.exe"),
            os.path.join(local, "Programs", "Opera GX", "opera.exe"),
            os.path.join(prog, "Opera", "launcher.exe"),
            os.path.join(prog86, "Opera", "launcher.exe"),
        ]
        for p in opera_candidates:
            if os.path.isfile(p):
                return p, "Opera"

        vivaldi_candidates = [
            os.path.join(local, "Vivaldi", "Application", "vivaldi.exe"),
            os.path.join(prog, "Vivaldi", "Application", "vivaldi.exe"),
            os.path.join(prog86, "Vivaldi", "Application", "vivaldi.exe"),
        ]
        for p in vivaldi_candidates:
            if os.path.isfile(p):
                return p, "Vivaldi"

        edge_candidates = [
            os.path.join(prog86, "Microsoft", "Edge", "Application", "msedge.exe"),
            os.path.join(prog, "Microsoft", "Edge", "Application", "msedge.exe"),
            os.path.join(local, "Microsoft", "Edge", "Application", "msedge.exe"),
        ]
        for p in edge_candidates:
            if os.path.isfile(p):
                return p, "Microsoft Edge"

    if sys.platform == "darwin":
        mac_paths = [
            ("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "Google Chrome"),
            ("/Applications/Brave Browser.app/Contents/MacOS/Brave Browser", "Brave Browser"),
            ("/Applications/Chromium.app/Contents/MacOS/Chromium", "Chromium"),
            ("/Applications/Opera.app/Contents/MacOS/Opera", "Opera"),
            ("/Applications/Vivaldi.app/Contents/MacOS/Vivaldi", "Vivaldi"),
            ("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge", "Microsoft Edge"),
        ]
        for p, name in mac_paths:
            if os.path.isfile(p):
                return p, name

    linux_names = [
        ("google-chrome-stable", "Google Chrome"),
        ("google-chrome", "Google Chrome"),
        ("brave-browser", "Brave Browser"),
        ("brave", "Brave Browser"),
        ("chromium", "Chromium"),
        ("chromium-browser", "Chromium"),
        ("opera", "Opera"),
        ("vivaldi", "Vivaldi"),
        ("msedge", "Microsoft Edge"),
        ("microsoft-edge", "Microsoft Edge"),
    ]
    for binary_name, friendly_name in linux_names:
        p = shutil.which(binary_name)
        if p and "WindowsApps" not in p and os.path.isfile(p):
            return p, friendly_name

    return None, None

def open_browser_on_device(url: str) -> bool:
    cmds = [
        ["termux-open-url", url],
        ["termux-open", url],
        ["am", "start", "--user", "0", "-a", "android.intent.action.VIEW", "-d", url, "-n", "com.android.chrome/com.google.android.apps.chrome.Main"],
        ["am", "start", "-a", "android.intent.action.VIEW", "-d", url, "-n", "com.android.chrome/com.google.android.apps.chrome.Main"],
        ["am", "start", "--user", "0", "-a", "android.intent.action.VIEW", "-d", url],
        ["am", "start", "-a", "android.intent.action.VIEW", "-d", url],
        ["/system/bin/am", "start", "--user", "0", "-a", "android.intent.action.VIEW", "-d", url, "-n", "com.android.chrome/com.google.android.apps.chrome.Main"],
        ["/system/bin/am", "start", "-a", "android.intent.action.VIEW", "-d", url, "-n", "com.android.chrome/com.google.android.apps.chrome.Main"],
        ["/system/bin/am", "start", "--user", "0", "-a", "android.intent.action.VIEW", "-d", url],
        ["/system/bin/am", "start", "-a", "android.intent.action.VIEW", "-d", url],
        ["xdg-open", url],
    ]
    for cmd in cmds:
        try:
            exe = shutil.which(cmd[0]) or (cmd[0] if os.path.exists(cmd[0]) else None)
            if exe:
                cmd_to_run = [exe] + cmd[1:]
                subprocess.Popen(cmd_to_run, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True
        except Exception:
            continue
    try:
        webbrowser.open(url, new=2)
        return True
    except Exception:
        return False

class ReusableTCPServer(ThreadingHTTPServer):
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        err_type = sys.exc_info()[0]
        if err_type in (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
            return
        super().handle_error(request, client_address)

class CdpClient:
    def __init__(self, ws_url: str):
        if not HAVE_WEBSOCKET:
            raise RuntimeError("websocket-client library is required for CDP connection.")
        self._id = 0
        self._pending: Dict[int, Tuple[threading.Event, Dict[str, Any]]] = {}
        self.ws = websocket.create_connection(ws_url, timeout=10)
        threading.Thread(target=self._read_loop, daemon=True).start()

    def _read_loop(self):
        while True:
            try:
                raw = self.ws.recv()
            except Exception:
                break
            if not raw:
                continue
            try:
                msg = json.loads(raw)
            except Exception:
                continue
            mid = msg.get("id")
            if mid is not None and mid in self._pending:
                evt, slot = self._pending.pop(mid)
                slot["result"] = msg.get("result")
                evt.set()

    def send(self, method: str, params: Optional[dict] = None, timeout: float = 10.0) -> dict:
        self._id += 1
        mid = self._id
        slot: Dict[str, Any] = {}
        evt = threading.Event()
        self._pending[mid] = (evt, slot)
        self.ws.send(json.dumps({"id": mid, "method": method, "params": params or {}}))
        if not evt.wait(timeout):
            raise TimeoutError(f"CDP call {method} timed out")
        return slot.get("result") or {}

    def evaluate(self, expression: str) -> Any:
        res = self.send("Runtime.evaluate", {"expression": expression, "returnByValue": True})
        return res.get("result", {}).get("value")

    def close(self):
        try:
            self.ws.close()
        except Exception:
            pass

class GhostyCaptchaRelay:

    def __init__(
        self,
        host: str = "0.0.0.0",
        port: int = 8787,
        browser_path: Optional[str] = None,
        auto_open_browser: bool = True,
    ):
        self.host = host
        self.port = port
        self.browser_path = browser_path
        self.auto_open_browser = auto_open_browser
        self.state: Dict[str, Any] = {
            "frame": b"",
            "rect": None,
            "solved": False,
            "claimed": False,
            "quest_name": "",
            "reward_name": "",
            "promo_code": "",
            "error": "",
            "token": "",
        }
        self.lock = threading.Lock()
        self.cdp_ref: Dict[str, Any] = {"cdp": None}
        self.proc: Optional[subprocess.Popen] = None
        self.server: Optional[ReusableTCPServer] = None
        self.server_thread: Optional[threading.Thread] = None

    def mark_claimed(self, quest_name: str, reward_name: str = "", promo_code: str = "") -> None:

        with self.lock:
            self.state["claimed"] = True
            self.state["quest_name"] = quest_name
            self.state["reward_name"] = reward_name
            self.state["promo_code"] = promo_code

        threading.Thread(target=self._delayed_cleanup, args=(30,), daemon=True).start()

    def mark_failed(self, error_msg: str) -> None:

        with self.lock:
            self.state["error"] = error_msg
        threading.Thread(target=self._delayed_cleanup, args=(12,), daemon=True).start()

    def _delayed_cleanup(self, delay: int = 30) -> None:
        time.sleep(delay)
        self.cleanup()

    def _create_handler(self):
        relay_self = self

        class RelayHandler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def _send(self, code: int, body: Any, ctype: str = "application/json"):
                try:
                    data = body if isinstance(body, bytes) else body.encode("utf-8")
                    self.send_response(code)
                    self.send_header("Content-Type", ctype)
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                    self.send_header("Access-Control-Allow-Headers", "Content-Type, Accept")
                    self.end_headers()
                    self.wfile.write(data)
                except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                    pass

            def do_OPTIONS(self):
                try:
                    self.send_response(200)
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                    self.send_header("Access-Control-Allow-Headers", "Content-Type, Accept")
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                    pass

            def do_GET(self):
                try:
                    if self.path.startswith("/frame.jpg"):
                        with relay_self.lock:
                            frame = relay_self.state["frame"]
                        if frame:
                            self._send(200, frame, "image/jpeg")
                        else:
                            self._send(204, b"")
                    elif self.path.startswith("/status"):
                        with relay_self.lock:
                            st = {
                                "mode": relay_self.state.get("mode", "screencast"),
                                "sitekey": relay_self.state.get("sitekey", ""),
                                "rqdata": relay_self.state.get("rqdata", ""),
                                "solved": relay_self.state.get("solved", False),
                                "claimed": relay_self.state.get("claimed", False),
                                "quest_name": relay_self.state.get("quest_name", ""),
                                "reward_name": relay_self.state.get("reward_name", ""),
                                "promo_code": relay_self.state.get("promo_code", ""),
                                "error": relay_self.state.get("error", ""),
                                "rect": relay_self.state.get("rect"),
                            }
                        self._send(200, json.dumps(st))
                    elif self.path.startswith("/assets/") or self.path.endswith(".ttf"):
                        clean_name = os.path.basename(self.path.split("?")[0])
                        project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                        asset_file = os.path.join(project_root, "assets", clean_name)
                        if os.path.isfile(asset_file):
                            with open(asset_file, "rb") as af:
                                font_data = af.read()
                            ctype = "font/ttf" if asset_file.endswith(".ttf") else "application/octet-stream"
                            self._send(200, font_data, ctype)
                        else:
                            self._send(404, b"Not Found", "text/plain")
                    else:
                        self._send(200, PAGE_HTML, "text/html")
                except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                    pass

            def do_POST(self):
                try:
                    if self.path.startswith("/input"):
                        length = int(self.headers.get("Content-Length", 0))
                        payload = json.loads(self.rfile.read(length))
                        relay_self._dispatch_input(
                            payload.get("t"),
                            float(payload.get("x", 0)),
                            float(payload.get("y", 0)),
                        )
                        self._send(200, '{"ok":true}')
                    elif self.path.startswith("/solve"):
                        length = int(self.headers.get("Content-Length", 0))
                        payload = json.loads(self.rfile.read(length))
                        token_val = payload.get("token")
                        if token_val:
                            with relay_self.lock:
                                relay_self.state["token"] = token_val
                                relay_self.state["solved"] = True
                            self._send(200, '{"ok":true}')
                        else:
                            self._send(400, '{"error":"missing token"}')
                    else:
                        self._send(404, '{"ok":false}')
                except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError):
                    pass
                except Exception as e:
                    self._send(500, json.dumps({"error": str(e)}))

        return RelayHandler

    def _dispatch_input(self, kind: str, x: float, y: float):
        cdp = self.cdp_ref.get("cdp")
        if not cdp:
            return
        with self.lock:
            rect = self.state["rect"]
        if not rect:
            return

        px = float(rect["x"]) + x
        py = float(rect["y"]) + y

        try:
            if kind == "move":
                cdp.send("Input.dispatchMouseEvent", {
                    "type": "mouseMoved",
                    "x": px,
                    "y": py,
                    "button": "none",
                    "buttons": 0,
                })
            elif kind == "press":
                cdp.send("Input.dispatchMouseEvent", {
                    "type": "mouseMoved",
                    "x": px,
                    "y": py,
                    "button": "none",
                    "buttons": 0,
                })
                cdp.send("Input.dispatchMouseEvent", {
                    "type": "mousePressed",
                    "x": px,
                    "y": py,
                    "button": "left",
                    "buttons": 1,
                    "clickCount": 1,
                })
            elif kind == "release":
                cdp.send("Input.dispatchMouseEvent", {
                    "type": "mouseReleased",
                    "x": px,
                    "y": py,
                    "button": "left",
                    "buttons": 0,
                    "clickCount": 1,
                })
        except Exception:
            pass

    def _mirror_loop(self, cdp: CdpClient):
        while not self.state["solved"]:
            try:
                rect = cdp.evaluate(RECT_EXPR)
                if rect and rect.get("w") and rect.get("h"):
                    with self.lock:
                        self.state["rect"] = rect
                    clip_x = max(0.0, float(rect["x"]))
                    clip_y = max(0.0, float(rect["y"]))
                    shot = cdp.send("Page.captureScreenshot", {
                        "format": "jpeg",
                        "quality": 82,
                        "clip": {
                            "x": clip_x,
                            "y": clip_y,
                            "width": float(rect["w"]),
                            "height": float(rect["h"]),
                            "scale": 1,
                        },
                    })
                    if shot.get("data"):
                        with self.lock:
                            self.state["frame"] = base64.b64decode(shot["data"])
            except Exception:
                pass
            time.sleep(0.20)

    def _token_loop(self, cdp: CdpClient, timeout: int) -> str:
        deadline = time.time() + timeout
        while time.time() < deadline and not self.state["solved"]:
            try:
                token = cdp.evaluate(TOKEN_EXPR)
                if token:
                    clean = str(token).strip().strip('"').strip("'")
                    with self.lock:
                        self.state["solved"] = True
                        self.state["token"] = clean
                    return clean
            except Exception:
                pass
            time.sleep(0.4)
        return ""

    def solve_relay(
        self,
        sitekey: str,
        rqdata: Optional[str] = None,
        rqtoken: Optional[str] = None,
        token: Optional[str] = None,
        timeout: int = 300,
        quest_name: str = "Discord Quest",
    ) -> Optional[str]:

        is_direct_mode = False
        binary = None
        name = "Direct Web Solver (Universal Native)"

        if self.browser_path:
            binary, b_name = find_browser(self.browser_path)
            if binary:
                name = b_name
            else:
                is_direct_mode = True
        else:
            is_direct_mode = True

        if is_direct_mode:
            ui.log_info("Launching Direct Web Solver (Fast Native Verification)...")

        with self.lock:
            self.state = {
                "mode": "direct" if is_direct_mode else "screencast",
                "sitekey": sitekey,
                "rqdata": rqdata or "",
                "frame": b"",
                "rect": None,
                "solved": False,
                "claimed": False,
                "quest_name": quest_name,
                "reward_name": "",
                "promo_code": "",
                "error": "",
                "token": "",
            }

        if os.name == "nt":
            try:
                subprocess.run(
                    [
                        "netsh", "advfirewall", "firewall", "add", "rule",
                        f"name=Ghosty Captcha Relay {self.port}",
                        "dir=in", "action=allow", "protocol=TCP",
                        f"localport={self.port}",
                    ],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=3,
                )
            except Exception:
                pass

        handler = self._create_handler()
        try:
            self.server = ReusableTCPServer((self.host, self.port), handler)
        except OSError:
            self.port = random.randint(18000, 30000)
            self.server = ReusableTCPServer((self.host, self.port), handler)

        self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.server_thread.start()

        local_ip = get_local_ip()
        ui.log_relay_online(local_ip, self.port, quest_name, engine_name=name)

        if self.auto_open_browser:
            local_target_url = f"http://127.0.0.1:{self.port}/"
            threading.Thread(target=open_browser_on_device, args=(local_target_url,), daemon=True).start()

        if is_direct_mode:
            start_t = time.time()
            try:
                while time.time() - start_t < timeout:
                    with self.lock:
                        if self.state.get("solved") and self.state.get("token"):
                            return self.state["token"]
                        if self.state.get("error"):
                            return None
                    time.sleep(0.5)
                ui.log_warn("Direct captcha solver timed out waiting for user response.")
                return None
            finally:
                with self.lock:
                    was_solved = self.state.get("solved", False)
                if not was_solved:
                    self.cleanup()

        cdp_port = random.randint(20000, 60000)
        profile_dir = os.path.join(
            os.environ.get("TEMP", os.environ.get("TMP", os.getcwd())),
            f"ghosty_relay_{cdp_port}",
        )

        cmd = [
            binary,
            f"--remote-debugging-port={cdp_port}",
            "--remote-allow-origins=*",
            f"--user-data-dir={profile_dir}",
            "--no-first-run",
            "--window-size=1280,900",
            "--headless=new",
            "--disable-gpu",
            "--hide-scrollbars",
            "--mute-audio",
            "--no-sandbox",
            "--disable-extensions",
            "--disable-background-networking",
            f"--user-agent={USER_AGENT}",
            "--disable-blink-features=AutomationControlled",
            "about:blank",
        ]

        try:
            self.proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            ui.log_warn(f"Failed to spawn headless engine '{name}': {e}. Switching to Direct Web Solver mode...")
            self.proc = None

        cdp_http = f"http://127.0.0.1:{cdp_port}"
        cdp_online = False
        if self.proc:
            for _ in range(35):
                try:
                    with urllib.request.urlopen(f"{cdp_http}/json/version", timeout=2) as r:
                        r.read()
                        cdp_online = True
                        break
                except Exception:
                    time.sleep(0.3)

        if not cdp_online:
            if self.proc:
                try:
                    self.proc.kill()
                except Exception:
                    pass
                self.proc = None
            ui.log_warn("Headless engine timed out. Switching to Direct In-Browser Solver mode...")
            with self.lock:
                self.state["mode"] = "direct"

            start_t = time.time()
            try:
                while time.time() - start_t < timeout:
                    with self.lock:
                        if self.state.get("solved") and self.state.get("token"):
                            return self.state["token"]
                        if self.state.get("error"):
                            return None
                    time.sleep(0.5)
                ui.log_warn("Direct captcha solver timed out waiting for user response.")
                return None
            finally:
                with self.lock:
                    was_solved = self.state.get("solved", False)
                if not was_solved:
                    self.cleanup()

        cdp_client: Optional[CdpClient] = None
        try:
            target = f"{cdp_http}/json/new?about:blank"
            try:
                req = urllib.request.Request(target, method="PUT")
                with urllib.request.urlopen(req, timeout=10) as r:
                    tab = json.loads(r.read())
            except Exception:
                with urllib.request.urlopen(target, timeout=10) as r:
                    tab = json.loads(r.read())

            cdp_client = CdpClient(tab["webSocketDebuggerUrl"])
            self.cdp_ref["cdp"] = cdp_client

            cdp_client.send("Page.enable")
            cdp_client.send("Runtime.enable")
            cdp_client.send("Network.enable")

            try:
                cdp_client.send("Network.setUserAgentOverride", {
                    "userAgent": USER_AGENT,
                    "acceptLanguage": "en-US,en;q=0.9",
                    "platform": "Win32",
                })
            except Exception:
                pass

            try:
                cdp_client.send("Page.setBypassCSP", {"enabled": True})
            except Exception:
                pass

            stealth = (
                "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
                "window.chrome = { runtime: {} };"
            )
            if token:
                stealth += f"; try {{ window.localStorage.setItem('token', JSON.stringify({json.dumps(token)})); }} catch(e) {{}}"

            cdp_client.send("Page.addScriptToEvaluateOnNewDocument", {"source": stealth})
            cdp_client.send("Page.navigate", {"url": "https://discord.com/channels/@me"})

            time.sleep(3.5)
            cdp_client.send("Page.bringToFront")

            cdp_client.evaluate(BOOT_EXPR.format(
                sitekey=json.dumps(sitekey),
                rqdata=json.dumps(rqdata),
            ))

            for _ in range(40):
                try:
                    if cdp_client.evaluate("window.__ghcId !== undefined"):
                        break
                except Exception:
                    pass
                time.sleep(0.4)

            threading.Thread(target=self._mirror_loop, args=(cdp_client,), daemon=True).start()

            solved_token = self._token_loop(cdp_client, timeout)
            return solved_token if solved_token else None

        except Exception as cdp_err:
            ui.log_warn(f"Headless CDP session error: {cdp_err}. Switching to Direct In-Browser Solver mode...")
            with self.lock:
                self.state["mode"] = "direct"
            start_t = time.time()
            while time.time() - start_t < timeout:
                with self.lock:
                    if self.state.get("solved") and self.state.get("token"):
                        return self.state["token"]
                    if self.state.get("error"):
                        return None
                time.sleep(0.5)
            ui.log_warn("Direct captcha solver timed out waiting for user response.")
            return None

        finally:
            if cdp_client:
                cdp_client.close()

            if self.proc:
                try:
                    self.proc.terminate()
                    self.proc.wait(timeout=2)
                except Exception:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
                self.proc = None

            with self.lock:
                was_solved = self.state.get("solved", False)
            if not was_solved:
                self.cleanup()

    def cleanup(self):

        if self.proc:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=2)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
            self.proc = None

        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except Exception:
                pass
            self.server = None

    async def async_solve(
        self,
        sitekey: str,
        rqdata: Optional[str] = None,
        rqtoken: Optional[str] = None,
        token: Optional[str] = None,
        timeout: int = 300,
        quest_name: str = "Discord Quest",
    ) -> Optional[str]:

        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None,
            self.solve_relay,
            sitekey,
            rqdata,
            rqtoken,
            token,
            timeout,
            quest_name,
        )
