from __future__ import annotations

import base64
import json
import os
import platform
import random
from typing import Any, Dict, Tuple

class GhostySecurityManager:

    DEFAULT_BUILD_NUMBER = 677695
    CHROME_VERSION = "120.0.0.0"
    ELECTRON_VERSION = "32.1.2"
    DISCORD_CLIENT_VERSION = "1.0.9184"

    def __init__(self, platform_override: str | None = None):
        self.system_os = self._ghosty_detect_os(platform_override)
        self.build_number = self.DEFAULT_BUILD_NUMBER
        self.user_agent = self._ghosty_generate_user_agent()
        self.super_properties = self._ghosty_build_super_properties()

    def _ghosty_detect_os(self, override: str | None) -> str:
        if override:
            return override.lower()
        return "windows"

    def _ghosty_generate_user_agent(self) -> str:
        if self.system_os == "windows":
            return (
                f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                f"(KHTML, like Gecko) discord/{self.DISCORD_CLIENT_VERSION} "
                f"Chrome/{self.CHROME_VERSION} Electron/{self.ELECTRON_VERSION} Safari/537.36"
            )
        elif self.system_os == "macos":
            return (
                f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
                f"(KHTML, like Gecko) discord/{self.DISCORD_CLIENT_VERSION} "
                f"Chrome/{self.CHROME_VERSION} Electron/{self.ELECTRON_VERSION} Safari/537.36"
            )
        elif self.system_os == "android":
            return "Discord-Android/350.6;RNA:15;Brand:google;Device:tangorpro;"
        else:
            return (
                f"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                f"(KHTML, like Gecko) discord/{self.DISCORD_CLIENT_VERSION} "
                f"Chrome/{self.CHROME_VERSION} Electron/{self.ELECTRON_VERSION} Safari/537.36"
            )

    def _ghosty_build_super_properties(self) -> str:
        os_str = "Windows"
        os_ver = "10.0.22631"
        browser_str = "Discord Client"

        if self.system_os == "macos":
            os_str = "Mac OS X"
            os_ver = "14.5.0"
        elif self.system_os == "linux":
            os_str = "Linux"
            os_ver = "6.8.0"
        elif self.system_os == "android":
            os_str = "Android"
            os_ver = "15"
            browser_str = "Discord Android"

        props: Dict[str, Any] = {
            "os": os_str,
            "browser": browser_str,
            "device": "" if self.system_os != "android" else "Pixel 9 Pro",
            "system_locale": "en-US",
            "browser_user_agent": self.user_agent,
            "browser_version": self.DISCORD_CLIENT_VERSION,
            "os_version": os_ver,
            "referrer": "",
            "referring_domain": "",
            "referrer_current": "",
            "referring_domain_current": "",
            "release_channel": "stable",
            "client_build_number": self.build_number,
            "client_event_source": None,
            "has_client_mods": False,
        }
        raw_json = json.dumps(props, separators=(",", ":"))
        return base64.b64encode(raw_json.encode()).decode()

    def ghosty_get_http_headers(self, token: str) -> Dict[str, str]:
        headers = {
            "Authorization": token.strip(),
            "User-Agent": self.user_agent,
            "X-Super-Properties": self.super_properties,
            "Content-Type": "application/json",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "Origin": "https://discord.com",
            "Referer": "https://discord.com/channels/@me",
            "Sec-Ch-Ua": f'"Chromium";v="{self.CHROME_VERSION.split(".")[0]}", "Not;A=Brand";v="24", "Discord";v="1"',
            "Sec-Ch-Ua-Mobile": "?1" if self.system_os == "android" else "?0",
            "Sec-Ch-Ua-Platform": f'"{self.system_os.capitalize()}"',
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
            "X-Discord-Locale": "en-US",
            "X-Discord-Timezone": "America/New_York",
        }
        return headers

    @staticmethod
    def ghosty_generate_jitter(base_min: float, base_max: float, jitter_spread: float = 4.0) -> float:
        val = random.uniform(base_min, base_max)
        gaussian_jitter = random.gauss(0.0, jitter_spread / 3.0)
        return max(base_min * 0.9, val + gaussian_jitter)
