from __future__ import annotations

import asyncio
import os
import random
import sys
from typing import List, Optional

from core import (
    GhostyGatewayManager,
    GhostyQuest,
    GhostyQuestHeart,
    GhostyRestClient,
    GhostySecurityManager,
    GhostyTokenManager,
    GhostyConfig,
    GhostyConfigManager,
    GhostyCaptchaRelay,
    ui,
)

class GhostySuiteApp:

    def __init__(self):
        self.config_mgr = GhostyConfigManager("config.json")
        self.config: GhostyConfig = self.config_mgr.ghosty_load_config()
        self.relay: GhostyCaptchaRelay = GhostyCaptchaRelay(
            host=self.config.relay_host,
            port=self.config.relay_port,
            browser_path=self.config.browser_path,
            auto_open_browser=self.config.auto_open_browser,
        )
        self.token_mgr = GhostyTokenManager("tokens.txt")
        self.security = GhostySecurityManager()
        self.tokens: List[str] = self.token_mgr.ghosty_load_tokens()
        self.active_token_idx: int = 0
        self.active_username: str = ""

        self.current_rest: Optional[GhostyRestClient] = None
        self.current_gateway: Optional[GhostyGatewayManager] = None
        self.current_heart: Optional[GhostyQuestHeart] = None
        self.all_quests: List[GhostyQuest] = []
        self.active_quests: List[GhostyQuest] = []

    async def _ghosty_attach_account(self, token_idx: int) -> bool:

        if not (0 <= token_idx < len(self.tokens)):
            ui.log_error(f"Invalid account index: {token_idx}")
            return False

        if self.current_gateway:
            await self.current_gateway.ghosty_disconnect()
        if self.current_rest:
            await self.current_rest.ghosty_close()

        self.active_token_idx = token_idx
        token = self.tokens[token_idx]
        masked = token[:10] + "..." + token[-6:] if len(token) > 16 else token

        ui.log_info(f"Connecting account <{token_idx + 1:02d}> ({masked})...")

        self.current_gateway = GhostyGatewayManager(
            token, config=self.config, relay=self.relay
        )
        ui.log_info("Connecting discord.py-self Gateway & loading dynamic client build...")
        gw_connected = await self.current_gateway.ghosty_connect(timeout=14.0)

        http_client = self.current_gateway.http if gw_connected else None
        self.current_rest = GhostyRestClient(
            token,
            self.security,
            http_client=http_client,
            config=self.config,
            relay=self.relay,
        )

        if gw_connected:
            self.active_username = self.current_gateway.username or masked
            ui.log_success(f"Connected as @{self.active_username} (Gateway Online | Build Synchronized)")
        else:
            self.active_username = masked
            ui.log_warn("Gateway timed out. Operating in fallback REST mode.")

        self.current_heart = GhostyQuestHeart(
            self.current_rest, self.current_gateway, self.security
        )

        await self._ghosty_refresh_quests(silent=True)
        return True

    async def _ghosty_refresh_quests(self, silent: bool = False) -> List[GhostyQuest]:
        if not self.current_rest:
            return []
        try:
            if not silent:
                ui.log_info("Fetching live quest data from Discord API...")
            self.all_quests = await self.current_rest.ghosty_fetch_quests()

            self.active_quests = [q for q in self.all_quests if not q.is_expired]
            if not silent:
                ui.log_success(
                    f"Retrieved {len(self.active_quests)} active quests "
                    f"({len(self.all_quests) - len(self.active_quests)} expired archived)"
                )
            return self.active_quests
        except Exception as err:
            ui.log_error(f"Failed to fetch quests: {err}")
            return []

    def _ghosty_render_screen(self):
        ui.clear_screen()
        gw_status = (
            self.current_gateway is not None and self.current_gateway.is_connected
        )
        header_text = ui.render_header(
            token_count=len(self.tokens),
            active_account=self.active_username,
            gateway_connected=gw_status,
            active_quests_count=len(self.active_quests),
            relay_enabled=self.config.captcha_relay,
            relay_port=self.config.relay_port,
        )
        print(header_text)

    async def ghosty_start(self) -> None:
        ui.clear_screen()

        if not self.tokens:
            print("\n" + ui.center(f"{ui.fg_rgb(*ui.YELLOW_GOLD)}{ui.BOLD}[!] No Discord account tokens found in tokens.txt.{ui.RESET}"))
            token_in = input(f"\n   {ui.fg_rgb(*ui.CYAN_ELECTRIC)}Enter Discord Account Token > {ui.RESET}").strip()
            if not token_in:
                ui.log_error("Token is required to proceed. Exiting.")
                return
            self.tokens.append(token_in)
            self.token_mgr.ghosty_save_token(token_in)

        await self._ghosty_attach_account(0)

        while True:
            self._ghosty_render_screen()
            print()
            prompt = (
                f"   {ui.fg_rgb(*ui.CYAN_ELECTRIC)}{ui.BOLD}GhoSty Control{ui.RESET} "
                f"{ui.fg_rgb(*ui.GRAY_MUTED)}[01-09]{ui.RESET} > "
            )
            choice = input(prompt).strip().lower()

            if choice.isdigit() and len(choice) == 1:
                choice = f"0{choice}"

            if choice in ("01", "1", "list"):

                await self._ghosty_refresh_quests(silent=True)
                table_lines = ui.render_quests_table(self.active_quests, title_prefix="CURRENTLY ACTIVE DISCORD QUESTS")
                print()
                for line in table_lines:
                    print(line)
                print()
                input(f"   {ui.fg_rgb(*ui.GRAY_MUTED)}Press Enter to return to menu...{ui.RESET}")

            elif choice in ("02", "2", "solve"):

                await self._ghosty_refresh_quests(silent=True)
                table_lines = ui.render_quests_table(self.active_quests, title_prefix="SELECT AN ACTIVE QUEST TO SOLVE")
                print()
                for line in table_lines:
                    print(line)
                print()

                q_sel = input(f"   {ui.fg_rgb(*ui.GREEN_NEON)}Select Quest Number to Solve [1-{len(self.active_quests)}] > {ui.RESET}").strip()
                if q_sel.isdigit() and 1 <= int(q_sel) <= len(self.active_quests):
                    target_quest = self.active_quests[int(q_sel) - 1]
                    assert self.current_heart is not None
                    await self.current_heart.ghosty_solve_quest(target_quest)
                    await self._ghosty_refresh_quests(silent=True)
                else:
                    ui.log_error("Invalid quest selection.")
                input(f"\n   {ui.fg_rgb(*ui.GRAY_MUTED)}Press Enter to return...{ui.RESET}")

            elif choice in ("03", "3", "all"):

                await self._ghosty_refresh_quests(silent=True)
                incomplete = [q for q in self.active_quests if not q.completed]
                ui.log_info(f"Starting automatic solver for {len(incomplete)} active incomplete quests...")
                assert self.current_heart is not None

                for q in incomplete:
                    await self.current_heart.ghosty_solve_quest(q)
                    await asyncio.sleep(random.uniform(4.0, 7.0))

                await self._ghosty_refresh_quests(silent=True)

                for q in self.active_quests:
                    if q.completed and not q.claimed:
                        await self.current_heart.ghosty_claim_reward(q)

                await self._ghosty_refresh_quests(silent=True)
                ui.log_success("All eligible active quests processed.")
                input(f"\n   {ui.fg_rgb(*ui.GRAY_MUTED)}Press Enter to return...{ui.RESET}")

            elif choice in ("04", "4", "play"):

                await self._ghosty_refresh_quests(silent=True)
                play_quests = [
                    q for q in self.active_quests
                    if ("PLAY" in q.primary_task_type or "STREAM" in q.primary_task_type)
                    and not q.completed
                ]
                ui.log_info(f"Found {len(play_quests)} uncompleted active Play/Stream quests.")
                assert self.current_heart is not None

                for q in play_quests:
                    await self.current_heart.ghosty_solve_quest(q)
                    await asyncio.sleep(random.uniform(4.0, 7.0))

                await self._ghosty_refresh_quests(silent=True)
                input(f"\n   {ui.fg_rgb(*ui.GRAY_MUTED)}Press Enter to return...{ui.RESET}")

            elif choice in ("05", "5", "video"):

                await self._ghosty_refresh_quests(silent=True)
                video_quests = [
                    q for q in self.active_quests
                    if "WATCH_VIDEO" in q.primary_task_type and not q.completed
                ]
                ui.log_info(f"Found {len(video_quests)} uncompleted active Video quests.")
                assert self.current_heart is not None

                for q in video_quests:
                    await self.current_heart.ghosty_solve_quest(q)
                    await asyncio.sleep(random.uniform(3.0, 6.0))

                await self._ghosty_refresh_quests(silent=True)
                input(f"\n   {ui.fg_rgb(*ui.GRAY_MUTED)}Press Enter to return...{ui.RESET}")

            elif choice in ("06", "6", "claim"):

                await self._ghosty_refresh_quests(silent=True)
                assert self.current_heart is not None

                completed_quests = [q for q in self.all_quests if q.completed]
                if not completed_quests:
                    ui.log_info("No completed quests found on this account.")
                else:
                    ui.log_info(f"Found {len(completed_quests)} completed quest(s) on this account:")
                    print()
                    for q in completed_quests:
                        reward_name = q.config.rewards[0].name if q.config.rewards else "Reward"
                        if q.claimed:
                            ui.log_success(f"Already Claimed: {q.config.quest_name} (Reward: {reward_name})")
                            code = await self.current_rest.ghosty_get_reward_code(q.id)
                            if code:
                                ui.log_reward_code(q.config.quest_name, code)
                        else:
                            await self.current_heart.ghosty_claim_reward(q)
                            await asyncio.sleep(random.uniform(2.0, 3.5))

                input(f"\n   {ui.fg_rgb(*ui.GRAY_MUTED)}Press Enter to return...{ui.RESET}")

            elif choice in ("07", "7", "switch"):

                print()
                table_lines = ui.render_accounts_table(self.tokens, self.active_token_idx)
                for line in table_lines:
                    print(line)
                print()

                acc_sel = input(f"   {ui.fg_rgb(*ui.PURPLE_LIGHT)}Enter Account Number to Switch To [1-{len(self.tokens)}] > {ui.RESET}").strip()
                if acc_sel.isdigit() and 1 <= int(acc_sel) <= len(self.tokens):
                    new_idx = int(acc_sel) - 1
                    await self._ghosty_attach_account(new_idx)
                else:
                    ui.log_error("Invalid account index.")
                input(f"\n   {ui.fg_rgb(*ui.GRAY_MUTED)}Press Enter to return...{ui.RESET}")

            elif choice in ("08", "8", "add"):

                print()
                new_token = input(f"   {ui.fg_rgb(*ui.CYAN_ELECTRIC)}Enter New Discord Token > {ui.RESET}").strip()
                if new_token:
                    self.tokens.append(new_token)
                    self.token_mgr.ghosty_save_token(new_token)
                    ui.log_success(f"Token added! Total accounts configured: {len(self.tokens)}")
                    switch_now = input(f"   {ui.fg_rgb(*ui.YELLOW_GOLD)}Switch to this new account now? (y/N) > {ui.RESET}").strip().lower()
                    if switch_now in ("y", "yes"):
                        await self._ghosty_attach_account(len(self.tokens) - 1)
                else:
                    ui.log_warn("Empty token entered. Aborted.")
                input(f"\n   {ui.fg_rgb(*ui.GRAY_MUTED)}Press Enter to return...{ui.RESET}")

            elif choice in ("09", "9", "0", "exit", "quit", "q"):

                ui.log_info("Shutting down GhoSty Quest Completor...")
                break

            else:
                ui.log_warn(f"Unknown command '{choice}'. Enter 01 to 09.")
                await asyncio.sleep(1.0)

        if self.current_gateway:
            await self.current_gateway.ghosty_disconnect()
        if self.current_rest:
            await self.current_rest.ghosty_close()

def ghosty_entrypoint():
    app = GhostySuiteApp()
    try:
        asyncio.run(app.ghosty_start())
    except KeyboardInterrupt:
        print(f"\n\n   {ui.fg_rgb(*ui.YELLOW_GOLD)}[!] Interrupted by user. Exiting cleanly.{ui.RESET}\n")

if __name__ == "__main__":
    ghosty_entrypoint()
